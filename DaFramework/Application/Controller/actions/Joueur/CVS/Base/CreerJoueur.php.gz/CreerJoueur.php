<?php

require_once 'GuildPortail/Outils/include.php';
require_once PATH_CLASSES . 'bJoueur.php';
require_once INC_GSESSION;

$joueur = new BJoueur();
$login = GSession::LirePost('Login');
$password = GSession::LirePost('Password');
$confirmPassword = GSession::LirePost('ConfirmationPassword');

$erreurs = $joueur->AjouterJoueur($login, $password, $confirmPassword);

if ($erreurs == '')
{
   	GSession::EcrireSession('loginJoueurConnecte', $joueur->LitID($login));
	GSession::EcrireSession('idJoueurConnecte', $joueur->LitID($login));
	require INC_FRECHARGERTOUT;
}

if ($erreurs !== '')
   	echo $erreurs;

?>
