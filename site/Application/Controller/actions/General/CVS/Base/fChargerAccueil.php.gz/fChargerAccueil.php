<?php

require_once 'cst.php';
require_once INC_GSESSION;
require_once INC_SFORM;


//if (!GSession::EstConnecte())
//{
	$creerJoueurForm = new SForm('form', true, 2, 1);

	$creerJoueurForm->SetCadreInputs(1, 1, 2, 1);
	$creerJoueurForm->AjouterInputText(1, 1, 'Login:', '', true, '', 30, -1, '', 'Ceci est ton adresse mail.', 'Il faut remplir le login.');
	$creerJoueurForm->AjouterInputText(2, 1, 'Mot de passe:', '', true, '', 20, -1, '', '', 'Il faut remplir le mot de passe.');

	$creerJoueurForm->SetCadreBoutons(2, 1, 1, 1);
	$creerJoueurForm->AjouterInputButton(1, 1, '', 'Valider', 'Validation en cours', true, 'test', true, true);


	$connexionForm = new SForm('form', true, 2, 1);

	$connexionForm->SetCadreInputs(1, 1, 2, 1);
	//$connexionForm->AjouterInputText(1, 1, 'Login:', '', true, '', 30, -1, '', 'Ceci est ton adresse mail.', 'Il faut remplir le login.');
	$select = $connexionForm->AjouterInputNewText(1, 1, 'Login:', true, '', 70, 70, '', 'Ceci est ton adresse mail.', 'Il faut remplir le login.');
	$select->AjouterFormulaire('Cr�er un compte', $creerJoueurForm);
	$connexionForm->AjouterInputText(2, 1, 'Mot de passe:', '', true, '', 20, -1, '', '', 'Il faut remplir le mot de passe.');

	$connexionForm->SetCadreBoutons(2, 1, 1, 1);
	$connexionForm->AjouterInputButton(1, 1, '', 'Valider', 'Validation en cours', true, 'test', true, true);

	GContexte::AjouterContenu(CADRE_CONTENU, $connexionForm);
//}

?>
