<?php

require_once 'cst.php';
require_once INC_GSESSION;
require_once INC_SFORM;
require_once PATH_METIER.'mListeGroupes.php';


/*$mListeGroupes = new MListeGroupes(false);
$mListeGroupes->AjouterToutesColSelection();
$mListeGroupes->AjouterColOrdre(COL_LIBELLE);
$mListeGroupes->Charger();*/

$selectGroupe = new SForm('selgpe', 1, 1, false, false);
$selectGroupe->SetCadreInputs(1, 1, 1, 2);
$select = $selectGroupe->AjouterInputInfo(1, 1, GSession::Libelle(LIB_CON_JEU), ' - ', true);
$select = $selectGroupe->AjouterInputSelect(1, 2, GSession::Libelle(LIB_CON_GROUPE), '', true, GContexte::FormaterVariable($nomContexte, 'groupe'));
/*foreach($mListeGroupes->GetListe() as $groupe)
{
   	$select->AjouterElement($groupe->Id(), $groupe->Libelle());
}*/

GContexte::AjouterContenu(CADRE_INFO_GROUPE, $selectGroupe);

?>
