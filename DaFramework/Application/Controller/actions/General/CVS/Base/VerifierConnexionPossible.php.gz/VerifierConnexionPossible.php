<?php

require_once 'GuildPortail/Outils/include.php';
require_once PATH_CLASSES . 'bJoueur.php';
require_once INC_GSESSION;

$result = '';
$joueur = new BJoueur();

$login = GSession::LirePost('Login');
$password = GSession::LirePost('Password');

if ($joueur->Existe($login, $password) != true || $login == NULL || $password == NULL)
	$result = AjouterErreur(ERR_CONNECTION_IMPOSSIBLE);
else
{
   	GSession::EcrireSession('loginJoueurConnecte', $login);
	GSession::EcrireSession('idJoueurConnecte', $joueur->LitID($login));
	require INC_FRECHARGERTOUT;
}

if (result !== '')
   	echo $result;

?>