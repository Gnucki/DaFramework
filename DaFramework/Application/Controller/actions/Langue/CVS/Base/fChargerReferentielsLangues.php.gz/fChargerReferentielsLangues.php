<?php

require_once 'cst.php';


if (GDroit::ADroitPopErreur(DROIT_ADMIN) === true)
{
	switch ($nomReferentiel)
	{
		case COL_ICONE:
		   	GReferentiel::AjouterReferentielFichiers(COL_ICONE, PATH_IMAGES.'Langue/', REF_FICHIERSEXTENSIONS_IMAGES);
			GReferentiel::GetDifferentielReferentielFichiersForSelect($nomReferentiel);
			break;
	}
}

?>
