<?php

require_once 'cst.php';
require_once INC_GSESSION;
require_once INC_SFORM;
require_once PATH_METIER.'mListeLangues.php';


$mListeLangues = new MListeLangues(false);
$mListeLangues->AjouterToutesColSelection();
$mListeLangues->AjouterColOrdre(COL_LIBELLE);
$mListeLangues->Charger();

$selectLangue = new SForm('sellan', 1, 1);
$selectLangue->SetCadreInputs(1, 1, 1, 1);
$select = $selectLangue->AjouterInputSelect(1, 1, GSession::Libelle(LIB_CON_LANGUE), '', true, GContexte::FormaterVariable($nomContexte, 'langue'));
foreach($mListeLangues->GetListe() as $langue)
{
   	$select->AjouterElement($langue->Id(), $langue->Libelle());
}

GContexte::AjouterContenu(CADRE_INFO_LANGUE, $selectLangue);

?>
