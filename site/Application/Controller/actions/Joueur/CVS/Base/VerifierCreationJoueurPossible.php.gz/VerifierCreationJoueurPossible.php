<?php
require_once 'GuildPortail/Outils/include.php';
require_once PATH_CLASSES.'bJoueur.php';

$joueur = new BJoueur();
echo $joueur->PeutAjouter($_POST['Login'], $_POST['Password'], $_POST['ConfirmationPassword']);
?>
