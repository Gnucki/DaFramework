<?php

require_once 'GuildPortail/Outils/include.php';
require_once PATH_CLASSES . 'bPersonnage.php';
require_once INC_GSESSION;

if ($_POST['Jeu'] != null)
	$personnage = new BPersonnage();
else
	$personnage = GSession::LireSession('PersoEnModification');

if ($personnage)
   	echo $personnage->VerifierDonneesValides($_POST['Jeu'], $_POST['Serveur'], $_POST['Classe'], $_POST['Utilite'], $_POST['Niveau'], $_POST['Nom']);

?>