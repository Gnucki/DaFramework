<?php

require_once 'GuildPortail/Outils/include.php';
require_once PATH_CLASSES . 'bGroupe.php';
require_once INC_GSESSION;

if ($_POST['Jeu'] != null)
	$groupe = new BGroupe();
else
	$groupe = GSession::LireSession('GroupeEnModification');

if ($groupe)
   	echo $groupe->VerifierDonneesValides($_POST['Jeu'], $_POST['TypeGroupe'], $_POST['Serveur'], $_POST['Nom']);

?>