<?php

require_once 'cst.php';
require_once 'GuildPortail/Outils/include.php';
require_once PATH_STRUCTURE.'sBalise.php';
require_once PATH_STRUCTURE.'sLabel.php';
require_once PATH_STRUCTURE.'sInput.php';
require_once PATH_STRUCTURE.'sChamp.php';
require_once PATH_OUTILS.'outils.php';
require_once PATH_CLASSES.'bLibelle.php';
require_once PATH_CLASSES.'bJoueur.php';
require_once INC_SLISTEPOSTSALTERNEE;
require_once INC_GSESSION;

$joueur = new BJoueur();
if (!GSession::EstConnecte())
{
	$balise = new SBalise(BAL_DIV);
	$balise->AddProp(PROP_CLASS, FORM_CONNEXION);
	$balise->Attach(new SChamp("inputLogin", "text", BLibelle::Afficher(LIB_LOGIN)));
	$balisePwd = new SChamp("inputPassword", "password", BLibelle::Afficher(LIB_MOT_DE_PASSE));
	$erreurConnexion = new SLabel(BLibelle::Afficher(ERR_CONNECTION_IMPOSSIBLE), ERR_CONNECTION_IMPOSSIBLE);
	$erreurConnexion->AddProp("style", "display: none");
	$balisePwd->Attach($erreurConnexion);
	$balise->Attach($balisePwd);
	$boutonSeConnecter = new SInput("boutonLogin", "button", BLibelle::Afficher(LIB_SE_CONNECTER));
	$boutonSeConnecter->AddProp("onclick", "VerifierConnexionPossible();");
	$balise->Attach($boutonSeConnecter);
	$boutonCreerCompte = new SInput("boutonCreerCompte", "button", BLibelle::Afficher(LIB_CREER_UN_COMPTE));
	$boutonCreerCompte->AddProp("onclick", "ChargerCreationJoueur();");
	$balise->Attach($boutonCreerCompte);
	echo $balise->BuildHTML();
}
else
   	GSession::ChargerContextes(true);

?>
