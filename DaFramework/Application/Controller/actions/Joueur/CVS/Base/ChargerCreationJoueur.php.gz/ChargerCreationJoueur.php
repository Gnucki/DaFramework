<?php
require_once 'GuildPortail/Outils/include.php';
require_once PATH_STRUCTURE.'sBalise.php';
require_once PATH_STRUCTURE.'sLabel.php';
require_once PATH_STRUCTURE.'sInput.php';
require_once PATH_STRUCTURE.'sChamp.php';
require_once PATH_CLASSES.'bLibelle.php';

$balise = new SBalise("div");

// login
$baliseLogin = new SChamp("inputLogin", "text", BLibelle::Afficher(LIB_LOGIN));
$baliseLogin->AddProp("onkeyup", "VerifierCreationJoueurPossible();");
$baliseLogin->Attach(new SLabel(BLibelle::Afficher(ERR_LOGIN_NON_RENSEIGNE), ERR_LOGIN_NON_RENSEIGNE));
$baliseLogin->Attach(new SLabel(BLibelle::Afficher(ERR_LOGIN_DEJA_UTILISE), ERR_LOGIN_DEJA_UTILISE));
$balise->Attach($baliseLogin);

// password
$balisePassword = new SChamp("inputPassword", "password", BLibelle::Afficher(LIB_MOT_DE_PASSE));
$balisePassword->AddProp("onkeyup", "VerifierCreationJoueurPossible();");
$balisePassword->Attach(new SLabel(BLibelle::Afficher(ERR_MDP_NON_RENSEIGNE), ERR_MDP_NON_RENSEIGNE));
$balise->Attach($balisePassword);

// confirmation password
$baliseConfPassword = new SChamp("inputConfirmationPassword", "password", BLibelle::Afficher(LIB_CONFIRMATION_MOT_DE_PASSE));
$baliseConfPassword->AddProp("onkeyup", "VerifierCreationJoueurPossible();");
$baliseConfPassword->Attach(new SLabel(BLibelle::Afficher(ERR_CONF_MDP_NON_RENSEIGNE), ERR_CONF_MDP_NON_RENSEIGNE));
$baliseConfPassword->Attach(new SLabel(BLibelle::Afficher(ERR_CONF_MDP_INCORRECTE), ERR_CONF_MDP_INCORRECTE));
$balise->Attach($baliseConfPassword);

// bouton de cr�ation
$boutonCreation = new SInput("boutonCreerCompte", "button", BLibelle::Afficher(LIB_CREER_LE_COMPTE));
$boutonCreation->AddProp("disabled", "true");
$boutonCreation->AddProp("onclick", "CreerJoueur();");
$balise->Attach($boutonCreation);

// affichage
echo $balise->BuildHTML();
?>
