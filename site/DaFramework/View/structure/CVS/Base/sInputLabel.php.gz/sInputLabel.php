<?php

require_once 'cst.php';
require_once INC_SELEMENT;
require_once INC_SORGANISEUR;


define ('INPUTLABELPLACE_HAUT',0);
define ('INPUTLABELPLACE_GAUCHE',1);

define ('INPUT', '_input');
define ('INPUT_LABEL', '_input_label');
define ('SOUSINPUT', '_sousinput');
define ('SOUSINPUT_LABEL', '_sousinput_label');


// Factory permettant de cr�er des inputs avec des labels positionn�s ou non.
class SInputLabel extends SElement
{
   	protected $prefixIdClass;
   	protected $organiseur;
   	protected $sousLabels;

	public function __construct($prefixIdClass, $label, $input = NULL, $placeLabel = INPUTLABELPLACE_GAUCHE, $oblig = false, $sousLabel = false)
	{
		$classeInput = INPUT;
		$classeLabel = INPUT_LABEL;
		if ($sousLabel === true)
		{
			$classeInput = SOUSINPUT;
			$classeLabel = SOUSINPUT_LABEL;
		}

		$this->prefixIdClass = $prefixIdClass;
	   	parent::__construct($prefixIdClass.$classeInput);
		$this->AjouterClasse($classeInput);
		if ($oblig === true)
			$this->AjouterClasse($classeInput.'_oblig');

		$this->organiseur = NULL;
		$org = NULL;

		if ($placeLabel == INPUTLABELPLACE_HAUT)
		{
		   	$org = new SOrganiseur(2, 1);
			$org->AddClass('jq_fill');
		   	$elem = new SElement($prefixIdClass.$classeLabel);
			$elem->AjouterClasse($classeLabel);
			if ($oblig === true)
				$elem->AjouterClasse($classeLabel.'_oblig');
		   	$elem->SetText($label);
		   	$org->AttacherCellule(1, 1, $elem);

		   	$org->SetCelluleDominante(2, 1);
		   	if ($input != NULL)
		   	   	$org->AttacherCellule(2, 1, $input);
		}
		else if ($placeLabel == INPUTLABELPLACE_GAUCHE)
		{
			$org = new SOrganiseur(1, 2);
			$org->AddClass('jq_fill');
		   	$elem = new SElement($prefixIdClass.$classeLabel);
			$elem->AjouterClasse($classeLabel);
			if ($oblig === true)
				$elem->AjouterClasse($classeLabel.'_oblig');
		   	$elem->SetText($label);
		   	$org->AttacherCellule(1, 1, $elem);

		   	$org->SetCelluleDominante(1, 2);
		   	if ($input != NULL)
		   	   	$org->AttacherCellule(1, 2, $input);
		}

		if ($org != NULL)
		{
		   	$this->organiseur = $org;
			$this->Attach($this->organiseur);
		}

		$this->sousLabels = array();
	}

	public function AttacherInput($input)
	{
		if ($this->organiseur != NULL)
		{
		   	if ($placeLabel == INPUTLABELPLACE_HAUT)
			   	$this->organiseur->AttacherCellule(2, 1, $input);
			else if ($placeLabel == INPUTLABELPLACE_GAUCHE)
			   	$this->organiseur->AttacherCellule(1, 2, $input);
		}
	}

	// Inputs.
	public function AjouterInputSelect($label = '', $typeInput = '', $oblig = false, $retour = '', $info = '', $erreur = '', $type = '', $impact = '', $rechargeFonc = '')
	{
		$select = new SInputSelect($this->prefixIdClass, $typeInput, $oblig, $retour, $info, $erreur, $type, $impact, $rechargeFonc);
		$this->AjouterInput($label, $select, $oblig);
		return $select;
	}

	public function AjouterInputText($label = '', $typeInput = '', $oblig = false, $retour = '', $valeurParDefaut = '', $longueurMin = -1, $longueurMax = -1, $taille = -1, $tailleAuto = false, $unite = '', $info = '', $erreur = '', $formatValide = '', $min = NULL, $max = NULL)
	{
		$text = new SInputText($this->prefixIdClass, $typeInput, $oblig, $retour, $valeurParDefaut, $longueurMin, $longueurMax, $taille, $tailleAuto, $unite, $info, $erreur, $formatValide, $min, $max);
		$this->AjouterInput($label, $text, $oblig);
		return $text;
	}

	public function AjouterInputCheckbox()
	{
		/*if ($this->currentCadreInputs != NULL)
		{
			$this->currentCadreInputs->AjouterCellule();
		}*/
	}

	public function AjouterInputNewSelect($label = '', $oblig = false, $retour = '', $info = '', $erreur = '', $type = '', $impact = '', $rechargeFonc = '')
	{
		$new = new SInputNewSelect($this->prefixIdClass, $oblig, $retour, $info, $erreur, $type, $impact, $rechargeFonc);
		$this->AjouterInput($label, $new, $oblig);
		return $new;
	}

	public function AjouterInputNewText($label = '', $oblig = false, $retour = '', $valeurParDefaut = '', $longueurMax = -1, $taille = -1, $tailleAuto = false, $unite = '', $info = '', $erreur = '', $formatValide = '', $min = NULL, $max = NULL)
	{
		$new = new SInputNewText($this->prefixIdClass, $oblig, $retour, $valeurParDefaut, $longueurMax, $taille, $tailleAuto, $unite, $info, $erreur, $formatValide, $min, $max);
		$this->AjouterInput($label, $new, $oblig);
		return $new;
	}

	public function AjouterInputFile($label = '', $typeInput = '', $oblig = false, $retour = '', $id = '', $info = '', $erreur = '', $type = '')
	{
		$file = new SInputFile($this->prefixIdClass, $typeInput, $oblig, $retour, $id, $info, $erreur, $type);
		$this->AjouterInput($label, $file, $oblig);
		return $file;
	}

	protected function AjouterInput($label, $input, $oblig)
	{
		$elem = NULL;

		if ($label !== '')
			$elem = new SInputLabel($this->prefixIdClass, $label, $input, INPUTLABELPLACE_GAUCHE, $oblig, true);
		else
			$elem = $input;

		$this->sousLabels[] = $elem;
	}

	protected function ConstruireSousLabels()
	{
	   	$nbSousLabels = count($this->sousLabels);
	   	if ($nbSousLabels >= 1)
		{
		   	$org = new SOrganiseur(1, $nbSousLabels);
		   	for ($i = 0; $i <= ($nbSousLabels - 1); $i++)
			{
			   	$org->AttacherCellule(1, $i + 1, $this->sousLabels[$i]);
			}
			$this->organiseur->AttacherCellule(1, 2, $org);
		}
	}

	public function BuildHTML()
	{
	   	$this->ConstruireSousLabels();

	   	return parent::BuildHTML();
	}
}

?>