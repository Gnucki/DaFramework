<?php

require_once 'cst.php';
require_once INC_SCADRE;
require_once INC_SCLASSEUR;


if (GDroit::ADroitPopErreur(DROIT_ADMIN) === true)
{
   	$classeurAdministration = new SClasseur('admin', 'admin', true, true);
   	$cadreAdministration = new SCadre('admin', GSession::Libelle(LIB_ADM_ADMINISTRATION), $classeurAdministration, true, false);

	GContexte::AjouterContenu(CADRE_CONTENU_CONTENU, $cadreAdministration);

	GContexte::AjouterOnglet('admin', TABLE_VERSION, '', 'AjouterAuContexte', 'contexte='.CONT_ADMINISTRATION.'&'.GContexte::FormaterVariable(CONT_ADMINISTRATION, 'ongletContexte').'='.CONT_VERSION, false, GContexte::IsContexteExiste(CONT_VERSION, true));
	GContexte::AjouterOnglet('admin', TABLE_MONNAIE, '', 'AjouterAuContexte', 'contexte='.CONT_ADMINISTRATION.'&'.GContexte::FormaterVariable(CONT_ADMINISTRATION, 'ongletContexte').'='.CONT_MONNAIE, false, GContexte::IsContexteExiste(CONT_MONNAIE, true));
	GContexte::AjouterOnglet('admin', TABLE_COMMUNAUTE, '', 'AjouterAuContexte', 'contexte='.CONT_ADMINISTRATION.'&'.GContexte::FormaterVariable(CONT_ADMINISTRATION, 'ongletContexte').'='.CONT_COMMUNAUTE, false, GContexte::IsContexteExiste(CONT_COMMUNAUTE, true));
	GContexte::AjouterOnglet('admin', TABLE_LANGUE, '', 'AjouterAuContexte', 'contexte='.CONT_ADMINISTRATION.'&'.GContexte::FormaterVariable(CONT_ADMINISTRATION, 'ongletContexte').'='.CONT_LANGUE, false, GContexte::IsContexteExiste(CONT_LANGUE, true));
	GContexte::AjouterOnglet('admin', TABLE_TYPELIBELLE, '', 'AjouterAuContexte', 'contexte='.CONT_ADMINISTRATION.'&'.GContexte::FormaterVariable(CONT_ADMINISTRATION, 'ongletContexte').'='.CONT_TYPELIBELLE, false, GContexte::IsContexteExiste(CONT_TYPELIBELLE, true));
	GContexte::AjouterOnglet('admin', TABLE_LIBELLELIBRE, '', 'AjouterAuContexte', 'contexte='.CONT_ADMINISTRATION.'&'.GContexte::FormaterVariable(CONT_ADMINISTRATION, 'ongletContexte').'='.CONT_LIBELLELIBRE, false, GContexte::IsContexteExiste(CONT_LIBELLELIBRE, true));
	GContexte::AjouterOnglet('admin', TABLE_LIBELLETEXTELIBRE, '', 'AjouterAuContexte', 'contexte='.CONT_ADMINISTRATION.'&'.GContexte::FormaterVariable(CONT_ADMINISTRATION, 'ongletContexte').'='.CONT_LIBELLETEXTELIBRE, false, GContexte::IsContexteExiste(CONT_LIBELLETEXTELIBRE, true));
}

?>
