<?php

require_once 'cst.php';
require_once INC_SELEMORG;
require_once INC_SORGANISEUR;
require_once INC_SINPUTLABEL;
require_once INC_SINPUTSELECT;
require_once INC_SINPUTTEXT;
require_once INC_SINPUTCHECKBOX;
require_once INC_SINPUTBUTTON;
require_once INC_SINPUTNEWSELECT;
require_once INC_SINPUTNEWTEXT;
require_once INC_SINPUTFILE;
require_once INC_SINPUTIMAGE;


define ('FORM', '_form');
define ('FORM_INPUTS', '_form_inputs');
define ('FORM_BOUTONS', '_form_boutons');
define ('FORM_ERREURS', '_form_erreurs');

define ('FORM_JQ_ERREUR', 'jq_form_erreur');

define ('INPUTINFO', '_inputinfo');


// Formulaire.
class SForm extends SElemOrg
{
   	protected $prefixIdClass;
	protected $id;
	protected $currentCadre;
	protected $currentCadreInputs;
	protected $currentCadreBoutons;
	protected $nbLignes;
	protected $nbColonnes;
	protected $aCadreErreur;
	//protected $cadre;

	public function __construct($prefixIdClass, $nbLignes = 2, $nbColonnes = 1, $tabMaxLargeur = true, $equiCellules = true)
	{
		$this->prefixIdClass = $prefixIdClass;

		parent::__construct($nbLignes + 1, $nbColonnes, $this->prefixIdClass.FORM, $tabMaxLargeur, $equiCellules);
		$this->AjouterClasse(FORM);

		$this->currentCadre = NULL;
		$this->currentCadreInputs = NULL;
		$this->currentCadreBoutons = NULL;

		$this->id = FORM.mt_rand();
		$this->AddProp(PROP_ID, $this->id);

		$this->nbLignes = $nbLignes;
		$this->nbColonnes = $nbColonnes;
		$this->aCadreErreur = false;
	}

	public function SetCadreInputs($ligne, $colonne, $nbLignes = 1, $nbColonnes = 1, $tabMaxLargeur = true, $equiCellules = true)
	{
		$this->currentCadreInputs = $this->SetCadre($ligne, $colonne, $nbLignes, $nbColonnes, FORM_INPUTS, $tabMaxLargeur, $equiCellules);
		$this->currentCadre = $this->currentCadreInputs;
	}

	public function SetCadreBoutons($ligne, $colonne, $nbLignes = 1, $nbColonnes = 1, $tabMaxLargeur = true, $equiCellules = true)
	{
		$this->currentCadreBoutons = $this->SetCadre($ligne, $colonne, $nbLignes, $nbColonnes, FORM_BOUTONS, $tabMaxLargeur, $equiCellules);
		$this->currentCadre = $this->currentCadreBoutons;
	}

	protected function SetCadre($ligne, $colonne, $nbLignes, $nbColonnes, $class, $tabMaxLargeur, $equiCellules)
	{
		$elem = NULL;

		$elem = new SElemOrg($nbLignes, $nbColonnes, $this->prefixIdClass.$class, $tabMaxLargeur, $equiCellules);
		$elem->AjouterClasse($class);

		$this->AttacherCellule($ligne, $colonne, $elem);

		return $elem;
	}

	public function FusionnerCelluleCadre($ligne, $colonne, $nbLignes = 0, $nbColonnes = 0)
	{
		if ($this->currentCadre != NULL)
			$this->currentCadre->FusionnerCellule($ligne, $colonne, $nbLignes, $nbColonnes);
	}

	// Boutons.
	public function AjouterInputButton($ligne, $colonne, $typeInput, $libelle, $libelleOnClick = '', $cadre = '', $fonction = '', $ajax = false, $reset = false)
	{
		$button = NULL;
		if ($this->currentCadreBoutons != NULL)
		{
			if ($cadre === true)
				$cadre = $this->id;
			else
				$cadre = '';

			$button = new SInputButton($this->prefixIdClass, $typeInput, $libelle, $libelleOnClick, $cadre, $fonction, $ajax, $reset);
			$this->currentCadreBoutons->AttacherCellule($ligne, $colonne, $button);

			if ($ajax === true && $this->aCadreErreur !== true)
			{
				// Cadre qui récupère les erreurs (après retour ajax) du formulaire lors de sa validation.
				$elem = new SElement($this->prefixIdClass.FORM_ERREURS);
				$elem->AjouterClasse(FORM_ERREURS);
				$elem->AddClass(FORM_JQ_ERREUR.$this->id);
				$this->FusionnerCellule($this->nbLignes + 1, 1, 0, $this->nbColonnes - 1);
				$this->AttacherCellule($this->nbLignes + 1, 1, $elem);
				$this->aCadreErreur = true;
			}
		}
		return $button;
	}

	public function AjouterInputButtonAjouterAuContexte($ligne, $colonne, $contexte, $reset = true)
	{
	   	return $this->AjouterInputButtonValiderAjaxContexte($ligne, $colonne, $contexte, AJAXFONC_AJOUTERAUCONTEXTE, $reset);
	}

	public function AjouterInputButtonModifierDansContexte($ligne, $colonne, $contexte, $reset = true)
	{
	   	return $this->AjouterInputButtonValiderAjaxContexte($ligne, $colonne, $contexte, AJAXFONC_MODIFIERDANSCONTEXTE, $reset);
	}

	public function AjouterInputButtonSupprimerDuContexte($ligne, $colonne, $contexte, $reset = true)
	{
	   	return $this->AjouterInputButtonValiderAjaxContexte($ligne, $colonne, $contexte, AJAXFONC_SUPPRIMERDUCONTEXTE, $reset);
	}

	public function AjouterInputButtonChargerContextes($ligne, $colonne, $contexte, $reset = true)
	{
	   	return $this->AjouterInputButtonValiderAjaxContexte($ligne, $colonne, $contexte, AJAXFONC_CHARGERCONTEXTES, $reset);
	}

	public function AjouterInputButtonValiderAjaxContexte($ligne, $colonne, $contexte, $fonction, $reset = true)
	{
		$bouton = $this->AjouterInputButtonValiderAjax($ligne, $colonne, $fonction, $reset);
		$bouton->AjouterParamRetour('contexte', $contexte);
		return $bouton;
	}

	public function AjouterInputButtonValiderAjax($ligne, $colonne, $fonction = '', $reset = true)
	{
		$bouton = $this->AjouterInputButton($ligne, $colonne, '', GSession::Libelle(LIB_FOR_VALIDER), GSession::Libelle(LIB_FOR_VALIDER), true, $fonction, true, $reset);
		$bouton->AjouterParamRetour('cf', GSession::NumCheckFormulaire());
		return $bouton;
	}

	public function AjouterInputButtonAnnuler($ligne, $colonne)
	{
		$bouton = $this->AjouterInputButton($ligne, $colonne, '', GSession::Libelle(LIB_FOR_ANNULER), '', '', '$(this).trigger', false, true);
		$bouton->AjouterParamRetour('inputNewFormFermer');
		return $bouton;
	}

	// Inputs.
	public function AjouterInputSelect($ligne, $colonne, $label = '', $typeInput = '', $oblig = false, $retour = '', $info = '', $erreur = '', $type = '', $impact = '', $rechargeFonc = '')
	{
		$select = NULL;
		if ($this->currentCadreInputs != NULL)
		{
			$select = new SInputSelect($this->prefixIdClass, $typeInput, $oblig, $retour, $info, $erreur, $type, $impact, $rechargeFonc);
			$this->AjouterInput($ligne, $colonne, $label, $select, $oblig);
		}
		return $select;
	}

	public function AjouterInputText($ligne, $colonne, $label = '', $typeInput = '', $oblig = false, $retour = '', $valeurParDefaut = '', $longueurMin = -1, $longueurMax = -1, $taille = -1, $tailleAuto = false, $unite = '', $info = '', $erreur = '', $formatValide = '', $min = NULL, $max = NULL)
	{
		$text = NULL;
		if ($this->currentCadreInputs != NULL)
		{
			$text = new SInputText($this->prefixIdClass, $typeInput, $oblig, $retour, $valeurParDefaut, $longueurMin, $longueurMax, $taille, $tailleAuto, $unite, $info, $erreur, $formatValide, $min, $max);
			$this->AjouterInput($ligne, $colonne, $label, $text, $oblig);
		}
		return $text;
	}

	public function AjouterInputCheckbox($ligne, $colonne)
	{
		/*if ($this->currentCadreInputs != NULL)
		{
			$this->currentCadreInputs->AjouterCellule($ligne, $colonne, );
		}*/
	}

	public function AjouterInputNewSelect($ligne, $colonne, $label = '', $oblig = false, $retour = '', $info = '', $erreur = '', $type = '', $impact = '', $rechargeFonc = '')
	{
		$new = NULL;
		if ($this->currentCadreInputs != NULL)
		{
			$new = new SInputNewSelect($this->prefixIdClass, $oblig, $retour, $info, $erreur, $type, $impact, $rechargeFonc);
			$this->AjouterInput($ligne, $colonne, $label, $new, $oblig);
		}
		return $new;
	}

	public function AjouterInputNewText($ligne, $colonne, $label = '', $oblig = false, $retour = '', $valeurParDefaut = '', $longueurMax = -1, $taille = -1, $tailleAuto = false, $unite = '', $info = '', $erreur = '', $formatValide = '', $min = NULL, $max = NULL)
	{
		$new = NULL;
		if ($this->currentCadreInputs != NULL)
		{
			$new = new SInputNewText($this->prefixIdClass, $oblig, $retour, $valeurParDefaut, $longueurMax, $taille, $tailleAuto, $unite, $info, $erreur, $formatValide, $min, $max);
			$this->AjouterInput($ligne, $colonne, $label, $new, $oblig);
		}
		return $new;
	}

	public function AjouterInputFile($ligne, $colonne, $label = '', $typeInput = '', $oblig = false, $retour = '', $id = '', $info = '', $erreur = '', $type = '')
	{
		$file = NULL;
		if ($this->currentCadreInputs != NULL)
		{
			$file = new SInputFile($this->prefixIdClass, $typeInput, $oblig, $retour, $id, $info, $erreur, $type);
			$this->AjouterInput($ligne, $colonne, $label, $file, $oblig);
		}
		return $file;
	}

	public function AjouterInputInfo($ligne, $colonne, $label, $info, $oblig = false)
	{
	   	$elem = new SElement($this->prefixIdClass.INPUTINFO);
		$elem->AjouterClasse(INPUTINFO);
	   	$elem->SetText($info);
		$this->AjouterInput($ligne, $colonne, $label, $elem, $oblig, INPUTLABELPLACE_GAUCHE);
	}

	public function AjouterInputLabel($ligne, $colonne, $label, $oblig = false, $placeLabel = INPUTLABELPLACE_GAUCHE, $input = NULL)
	{
		$label = new SInputLabel($this->prefixIdClass, $label, $input, $placeLabel, $oblig);
		$this->currentCadreInputs->AttacherCellule($ligne, $colonne, $label);
		return $label;
	}

	protected function AjouterInput($ligne, $colonne, $label, $input, $oblig)
	{
		$elem = NULL;

		if ($label !== '')
			$elem = new SInputLabel($this->prefixIdClass, $label, $input, INPUTLABELPLACE_GAUCHE, $oblig);
		else
			$elem = $input;

		$this->currentCadreInputs->AttacherCellule($ligne, $colonne, $elem);
	}
}