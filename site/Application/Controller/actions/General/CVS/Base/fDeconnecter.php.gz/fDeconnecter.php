<?php

require_once 'cst.php';
require_once INC_GSESSION;

GSession::StartSession();
GSession::PurgeSession();

?>