<?php

require_once 'cst.php';
require_once INC_SELEMORG;
require_once INC_GCONTEXTE;
require_once INC_SFORM;


define ('LISTECLASS','_liste');
define ('LISTECLASS_TITRE','_liste_titre');
define ('LISTECLASS_TITREELEM','_liste_titreelem');
define ('LISTECLASS_ELEMENT','_liste_elem');
define ('LISTECLASS_ELEMCONSULT','_liste_elemconsult');
define ('LISTECLASS_ELEMMODIF','_liste_elemmodif');
define ('LISTECLASS_ELEMCREAT','_liste_elemcreat');
define ('LISTECLASS_ELEMMENU','_liste_elemmenu');
define ('LISTECLASS_ELEMMENU_ELEM','_liste_elemmenu_elem');
define ('LISTECLASS_ELEMCHAMP','_liste_elemchamp');

define ('LISTE_CHAMPLISTE_VALEURPARDEFAUT','valeurParDefaut');
define ('LISTE_CHAMPLISTE_ESTID','estId');
define ('LISTE_CHAMPLISTE_RETOURINVISIBLE','retourInvisible');
define ('LISTE_CHAMPLISTE_INPUTMODIFPARDEFAUT','inputModif');
define ('LISTE_CHAMPLISTE_INPUTCREATPARDEFAUT','inputCreat');
define ('LISTE_CHAMPLISTE_MIN','min');
define ('LISTE_CHAMPLISTE_MAX','max');
define ('LISTE_CHAMPLISTE_LONGUEURMIN','longmin');
define ('LISTE_CHAMPLISTE_LONGUEURMAX','longmax');
define ('LISTE_CHAMPLISTE_REGEXP','regexp');
define ('LISTE_CHAMPLISTE_NONNUL','nonnul');
define ('LISTE_CHAMPLISTE_INFO','info');
define ('LISTE_CHAMPLISTE_ERREUR','erreur');
define ('LISTE_CHAMPLISTE_AUTRESDONNEES','autre');
define ('LISTE_CHAMPLISTE_ENSESSION','enSession');

define ('LISTE_CHAMPTYPE_CONSULT','consult');
define ('LISTE_CHAMPTYPE_MODIF','modif');
define ('LISTE_CHAMPTYPE_CREAT','creat');

define ('LISTE_AUTRESDONNEES_SELECTDEPENDCHAMP','depchamp');
define ('LISTE_AUTRESDONNEES_SELECTIMPACT','impact');
define ('LISTE_AUTRESDONNEES_SELECTCOLID','scid');
define ('LISTE_AUTRESDONNEES_SELECTCOLLIB','sclib');
define ('LISTE_AUTRESDONNEES_SELECTCOLDESC','scdesc');
define ('LISTE_AUTRESDONNEES_TEXTTAILLE','ttaille');
define ('LISTE_AUTRESDONNEES_IMAGEVISUALISEUR','imgvisu');
define ('LISTE_AUTRESDONNEES_IMAGETYPE','imgtype');
define ('LISTE_AUTRESDONNEES_CHAMPFORMATE','cformat');

define ('LISTE_INPUTTYPE_SELECT','select');
define ('LISTE_INPUTTYPE_FILE','file');
define ('LISTE_INPUTTYPE_IMAGE','image');
define ('LISTE_INPUTTYPE_TEXT','text');
define ('LISTE_INPUTTYPE_CHECKBOX','checkbox');

define ('LISTE_CONTEXTE_ORDRE','ordre');
define ('LISTE_CONTEXTE_CHAMPS','champs');

define ('LISTE_MENU_ELEMENTS','menuElem');
define ('LISTE_MENU_ELEMENT_FONC','fonc');
define ('LISTE_MENU_ELEMENT_LIB','lib');
define ('LISTE_MENU_ELEMENT_AJAX','ajax');
define ('LISTE_MENU_ELEMENT_PARAM','param');
define ('LISTE_MENU_ELEMENT_CADRE','cadre');
define ('LISTE_MENU_ELEMENT_RESET','reset');

define ('LISTE_ETAGE_CONSULT','1');
define ('LISTE_ETAGE_MODIF','2');

define ('LISTE_ELEMENT_ID','id');
define ('LISTE_ELEMENT_ORDRE','ordre');
define ('LISTE_ELEMENT_RETOUR','retour');
define ('LISTE_ELEMENT_CONTENU','contenu');
define ('LISTE_ELEMENT_ACTION','action');
define ('LISTE_ELEMENT_VALEURCONSULT','consult');
define ('LISTE_ELEMENT_VALEURMODIF','modif');
define ('LISTE_ELEMENT_MODIFIE','modifie');

define ('LISTE_ELEMACTION_CREAT','creat');
define ('LISTE_ELEMACTION_MODIF','modif');
define ('LISTE_ELEMACTION_SUPP','supp');

define ('LISTE_JQ','jq_liste');
define ('LISTE_JQ_TYPE','jq_liste_type');
define ('LISTE_JQ_TYPESYNCHRO','jq_liste_typesynchro');
define ('LISTE_JQ_NUMERO','jq_liste_numero');
define ('LISTE_JQ_SORTABLE','jq_liste_sortable');
define ('LISTE_JQ_SORTABLE_FONCININ','jq_liste_sortable_foncinin');
define ('LISTE_JQ_SORTABLE_FONCINOUT','jq_liste_sortable_foncinout');
define ('LISTE_JQ_SORTABLE_FONCOUTIN','jq_liste_sortable_foncoutin');
define ('LISTE_JQ_SORTABLE_PARAMININ','jq_liste_sortable_paraminin');
define ('LISTE_JQ_SORTABLE_PARAMINOUT','jq_liste_sortable_paraminout');
define ('LISTE_JQ_SORTABLE_PARAMOUTIN','jq_liste_sortable_paramoutin');
define ('LISTE_JQ_ELEMENTMODELE','jq_liste_elementmodele');
define ('LISTE_JQ_ELEMENTCREATION','jq_liste_elementcreat');
define ('LISTE_JQ_ELEM','jq_liste_elem');
define ('LISTE_JQ_ELEM_MENUS','jq_liste_elem_menus');
define ('LISTE_JQ_ELEM_MENU','jq_liste_elem_menu');
define ('LISTE_JQ_ELEM_MENUELEM','jq_liste_elem_menuelem');
define ('LISTE_JQ_ELEM_MENUELEM_BOUTON','jq_liste_elem_menuelem_bouton');
define ('LISTE_JQ_ELEM_CHAMP','jq_liste_elem_champ');
define ('LISTE_JQ_ELEM_CHAMP_NOM','jq_liste_elem_champ_nom');
define ('LISTE_JQ_ELEM_CHAMP_TYPE','jq_liste_elem_champ_type');
define ('LISTE_JQ_ELEM_ETAGE','jq_liste_elem_etage');
define ('LISTE_JQ_ELEM_ETAGE_NUM','jq_liste_elem_etage_num');
define ('LISTE_JQ_ELEM_ETAGE_CHARGEFONC','jq_liste_elem_etage_chargefonc');
define ('LISTE_JQ_ELEM_ETAGE_CHARGEPARAM','jq_liste_elem_etage_chargeparam');
define ('LISTE_JQ_ELEMENT','jq_liste_element');
define ('LISTE_JQ_ELEMENT_ID','jq_liste_element_id');
define ('LISTE_JQ_ELEMENT_ORDRE','jq_liste_element_ordre');
define ('LISTE_JQ_ELEMENT_PARAM','jq_liste_element_param');
define ('LISTE_JQ_ELEMENT_MENUS','jq_liste_element_menus');
define ('LISTE_JQ_ELEMENT_MENU','jq_liste_element_menu');
define ('LISTE_JQ_ELEMENT_MENUELEM','jq_liste_element_menuelem');
define ('LISTE_JQ_ELEMENT_MENUELEM_LIB','jq_liste_element_menuelem_lib');
define ('LISTE_JQ_ELEMENT_MENUELEM_BOUTONCADRE','jq_liste_element_menuelem_boutoncadre');
define ('LISTE_JQ_ELEMENT_MENUELEM_BOUTONFONC','jq_liste_element_menuelem_boutonfonc');
define ('LISTE_JQ_ELEMENT_MENUELEM_BOUTONAJAX','jq_liste_element_menuelem_boutonajax');
define ('LISTE_JQ_ELEMENT_MENUELEM_BOUTONPARAM','jq_liste_element_menuelem_boutonparam');
define ('LISTE_JQ_ELEMENT_MENUELEM_BOUTONRESET','jq_liste_element_menuelem_boutonreset');
define ('LISTE_JQ_ELEMENT_CHAMPS','jq_liste_element_champs');
define ('LISTE_JQ_ELEMENT_CHAMP','jq_liste_element_champ');
define ('LISTE_JQ_ELEMENT_CHAMP_VALEUR','jq_liste_element_champ_valeur');
define ('LISTE_JQ_ELEMENT_CHAMP_NOM','jq_liste_element_champ_nom');
define ('LISTE_JQ_ELEMENT_CHAMP_TYPE','jq_liste_element_champ_type');
define ('LISTE_JQ_PAGE_CHANGEFONC','jq_liste_page_changefonc');
define ('LISTE_JQ_PAGE_CHANGEPARAM','jq_liste_page_changeparam');
define ('LISTE_JQ_PAGE_NAVIGATEUR','jq_liste_page_navigateur');
define ('LISTE_JQ_PAGE_BARREDEFILEMENT','jq_liste_page_barredefilement');
define ('LISTE_JQ_PAGE_PREC','jq_liste_page_prec');
define ('LISTE_JQ_PAGE_COURANTE','jq_liste_page_courante');
define ('LISTE_JQ_PAGE_SUIV','jq_liste_page_suiv');
define ('LISTE_JQ_PAGE_PREM','jq_liste_page_prem');
define ('LISTE_JQ_PAGE_DER','jq_liste_page_der');

define ('LISTE_JQFONCTION_MENUPOP','menuPop');
define ('LISTE_JQFONCTION_ETAGEGO','etageGo');

define ('LISTE_JQCADRE_ETAGE','etage');


// Mode d'emploi de la classe.
// 1 - Cr�er une classe d�riv�e.
// 2 - Surcharger la m�thode InitialiserChamps().
// 3 - Surcharger la m�thode AjouterElement().
// 4 - Surcharger la m�thode GetElemListeMenu() si vous voulez changer les menus accessibles via le menu d�roulant de l'�l�ment.
// 5 - Surcharger les m�thodes de gestion des droits: HasDroitConsultation($element), HasDroitModification($element), HasDroitCreation(), HasDroitSuppression($element).
// 6 - Surcharger la m�thode ConstruireLigneTitre() si vous voulez mettre une barre de titre � votre liste (pour les listes tableaux).
// 7 - Surcharger les m�thodes de cr�ation de l'affichage: ConstruireElemConsultation(), ConstruireElemModification(), ConstruireElemCreation(), en appelant la fontion parent et r�cup�rant le retour:
//	$conteneur = parent::Construire...(); $elem = new ...(); ...; $conteneur->Attach($elem); return $conteneur;

// Pour les exemples:
// define ('ID', 'id');
// define ('PRENOM', 'prenom');
// define ('NOM', 'nom');

// Classe servant de base pour les diff�rentes listes complexes (liste de personnages, de forums, d'amis, de grades, d'�v�nements, ...) du programme.
class SListe extends SElement
{
   	static protected $nbListesEnregistrees;
   	static protected $changementPage;
   	static protected $chargementEtage;
   	static protected $listeElemChargee;

   	protected $numero;
	protected $elements;
	protected $champs;
	protected $menus;
	protected $contexte;
	protected $typeSynchro;
	protected $listeContexte;
	protected $listeSuppressions;
	protected $rechargement;
	protected $nbElementsParPage;
	protected $nbElementsTotal;
	protected $numPageCourante;
	protected $numAnciennePage;
	protected $triable;
	protected $typeLiaison;
	protected $prefixIdClass;
	protected $foncAjaxCreation;
	protected $foncAjaxModification;
	protected $foncAjaxSuppression;
	protected $foncAjaxRechargement;
	protected $foncJsOnClick;
	protected $foncAjaxTriCreation;
	protected $foncAjaxTriModification;
	protected $foncAjaxTriSuppression;
	protected $chargement;
	protected $chargementModifDiffere;

    public function __construct($prefixIdClass, $typeSynchro, $contexte, $nbElementsParPage = 20, $nbElementsTotal = -1, $triable = false, $typeLiaison = '', $chargementModifDiffere = true, $foncJsOnClick = '', $foncAjaxTriCreation = '', $foncAjaxTriModification = AJAXFONC_MODIFIERDANSCONTEXTE, $foncAjaxTriSuppression = '', $foncAjaxCreation = AJAXFONC_AJOUTERAUCONTEXTE, $foncAjaxModification = AJAXFONC_MODIFIERDANSCONTEXTE, $foncAjaxSuppression = AJAXFONC_SUPPRIMERDUCONTEXTE, $foncAjaxRechargement = AJAXFONC_RECHARGER)
    {
       	$this->prefixIdClass = $prefixIdClass;

		if (self::$nbListesEnregistrees === NULL)
			self::$nbListesEnregistrees = array();

		// Affectation d'un num�ro � la liste qui permet, avec son typeSynchro, de la rendre unique et identifiable.
		if (!array_key_exists($typeSynchro, self::$nbListesEnregistrees))
		{
		   	$this->numero = 1;
			self::$nbListesEnregistrees[$typeSynchro] = 1;
		}
		else
		{
		   	$this->numero = self::$nbListesEnregistrees[$typeSynchro];
		   	self::$nbListesEnregistrees[$typeSynchro]++;
		}

		if (self::$listeElemChargee === NULL)
		   	self::$listeElemChargee = array();

       	parent::__construct($this->prefixIdClass.LISTECLASS, false);
       	$this->AjouterClasse(LISTECLASS);
       	$this->AddClass(LISTE_JQ);

		$this->elements = array();
		$this->champs = array();
		$this->menus = array();
		$this->chargement = true;
		$this->contexte = $contexte;
		$this->typeSynchro = $typeSynchro;
		$this->nbElementsParPage = $nbElementsParPage;
		$this->nbElementsTotal = $nbElementsTotal;
		$this->numPageCourante = GContexte::ListePageCourante($contexte, $typeSynchro, $this->numero);
		$this->numAnciennePage = $this->numPageCourante;
		$this->triable = $triable;
		$this->typeLiaison = $typeLiaison;
		$this->foncAjaxCreation = $foncAjaxCreation;
		$this->foncAjaxModification = $foncAjaxModification;
		$this->foncAjaxSuppression = $foncAjaxSuppression;
		$this->foncAjaxRechargement = $foncAjaxRechargement;
		$this->foncJsOnClick = $foncJsOnClick;
		$this->foncAjaxTriCreation = $foncAjaxTriCreation;
		$this->foncAjaxTriModification = $foncAjaxTriModification;
		$this->foncAjaxTriSuppression = $foncAjaxTriSuppression;
		$this->listeContexte = GContexte::Liste($contexte, $this->TypeSynchroPage());
		$this->listeSuppressions = $this->listeContexte;
		if ($this->listeContexte === NULL)
		    $this->listeContexte = array();
		$this->rechargement = false;
		$this->chargementModifDiffere = $chargementModifDiffere;
		//$this->AddProp(PROP_STYLE, 'visibility: hidden; height:0;');

		$this->InitialiserChamps();
		$this->InitialiserReferentiels();

		GSession::PoidsJavascript(15);
	}

	static public function SetChangementPage($page)
	{
	   	self::$changementPage = $page;
	}

	static public function SetChargementEtage($etage)
	{
	   	self::$chargementEtage = $etage;
	}

	// Initialisation des champs.
	protected function InitialiserChamps()
	{
	   	// $this->AjouterChamp(ID, -1, true, true);
		// $this->AjouterChamp(PRENOM, 'John');
		// $this->AjouterChamp(NOM, 'Doe');
		// ...
	}

	// Initialisation des r�f�rentiels pour tous les �l�ments.
	protected function InitialiserReferentiels()
	{
	   	/*$mListe = new MListePrenoms();
		$this->AjouterReferentiel(PRENOM, $mListe);*/
	}

	// Initialisation des r�f�rentiels d'un �l�ment en particulier.
	protected function InitialiserReferentielsElement($element)
	{
	   	/*$mListe = new MListePrenoms();
		$this->AjouterReferentiel(PRENOM, $mListe);*/
	}

	// Ajout d'un r�f�rentiel.
	protected function AjouterReferentiel($nom, MListeObjetsMetiers $mListe, $sauveCols = NULL, $dejaCharge = false)
	{
	   	$nomRef = '';
		if (is_array($nom))
		{
			foreach ($nom as $nomCol)
			{
			   	if ($nomRef !== '')
			   	   	$nomRef .= ',';
			   	$nomRef .= $nomCol;
			}
		}
		else
		   	$nomRef = $nom;

	   	GReferentiel::AjouterReferentiel($this->contexte.$nomRef, $mListe, $sauveCols, $dejaCharge);
	}

	// Ajout d'un r�f�rentiel fichiers.
	protected function AjouterReferentielFichiers($nom, $chemin, $extensions)
	{
	   	GReferentiel::AjouterReferentielFichiers($this->contexte.$nom, $chemin, $extensions);
	}

	// A impl�menter selon le cas (dans les classes d�riv�es).
	// On peut d�cider de ne pas s'en servir et directement injecter une liste d'objets m�tiers
	// avec la fonction InjecterListeObjetsMetiers($mListeObjetsMetiers).
	public function AjouterElement(/* $id, $prenom, $nom, $textNom*/)
	{
		// $elem = array();
		//$elem[ID] = $id;
		//$this.SetElemValeurChamp($elem, PRENOM, $prenom);
		//$this.SetElemValeurChamp($elem, NOM, $nom, $textNom);
		//...
		// $this->elements[] = $elem;
	}

	// Permet de r�cup�rer les informations d'une liste d'objets m�tiers:
	// - informations sur les champs (obligatoire, taille min/max, regexp, ...),
	// - liste des �l�ments � afficher.
	public function InjecterListeObjetsMetiers(MListeObjetsMetiers $mListeObjetsMetiers, $dejaChargee = false)
	{
	   	// Si on est dans le cas d'un changement de page, on v�rifie que c'est bien cette liste qui est vis�e.
	   	if (self::$changementPage !== NULL && self::$changementPage !== '')
	   	{
		    if (array_key_exists($this->TypeSynchro(), self::$changementPage) && array_key_exists($this->numero, self::$changementPage[$this->TypeSynchro()]))
			{
			   	// Si on change effectivement de page.
			   	if ($this->numPageCourante != self::$changementPage[$this->TypeSynchro()][$this->numero])
				{
				   	$this->numPageCourante = self::$changementPage[$this->TypeSynchro()][$this->numero];
				   	GContexte::ListePageCourante($this->contexte, $this->TypeSynchro(), $this->numero, $this->numPageCourante);
			   		GContexte::ListeActive($this->contexte, $this->AncienTypeSynchroPage(), true);
				}
			   	else
			   	   	$this->chargement = false;
			}
		    else
		       	$this->chargement = false;
		}
		// Si on est dans le cas d'un chargement d'�tage, on v�rifie que cette bien cette liste qui est vis�e.
		else if (self::$chargementEtage !== NULL && self::$chargementEtage !== '')
	   	{
		    if (!array_key_exists($this->TypeSynchro(), self::$chargementEtage) || !array_key_exists($this->numero, self::$chargementEtage[$this->TypeSynchro()]))
			   	$this->chargement = false;
		}

		if ($this->chargement === true)
		{
		   	// R�cup�ration des informations compl�mentaires sur les champs.
		   	// Pour que cela fonctionne, il faut que le nom du champ d�fini dans InitialisationChamps soit le m�me que
		   	// celui auquel il est li� dans l'objet m�tier de la liste.
		   	foreach ($this->champs as $nomChamp => &$champ)
		   	{
		   	   	$noms = $nomChamp;
				if (strpos($nomChamp, ',') !== false)
		   	   		$noms = explode(',', $nomChamp);
		   	   	$mObjetMetier = $mListeObjetsMetiers->GetObjetMetierReference();
		   	   	$champ[LISTE_CHAMPLISTE_MIN] = $mObjetMetier->GetChampMinFromTableau($noms);
		   	   	$champ[LISTE_CHAMPLISTE_MAX] = $mObjetMetier->GetChampMaxFromTableau($noms);
		   	   	$champ[LISTE_CHAMPLISTE_LONGUEURMIN] = $mObjetMetier->GetChampLongueurMinFromTableau($noms);
		   	   	$champ[LISTE_CHAMPLISTE_LONGUEURMAX] = $mObjetMetier->GetChampLongueurMaxFromTableau($noms);
		   	   	$champ[LISTE_CHAMPLISTE_REGEXP] = $mObjetMetier->GetChampRegExpFromTableau($noms);
		   	   	if ($champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] === NULL)
		   	   	   	$champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] = $mObjetMetier->GetChampValeurParDefautFromTableau($noms);
				$champ[LISTE_CHAMPLISTE_NONNUL] = $mObjetMetier->IsChampNonNulFromTableau($noms);
		   	}

		   	// R�cup�ration du nombre total d'�l�ments.
		   	if ($this->nbElementsTotal < 0)
				$this->nbElementsTotal = $mListeObjetsMetiers->GetNbElementsFromBase();

			// On v�rifie que le contenu de la liste n'a pas d�j� �t� charg� par une autre liste de m�me type.
			$listeElem = NULL;
			if (array_key_exists($this->TypeSynchroPage(), self::$listeElemChargee))
			{
			   	$listeElem = self::$listeElemChargee[$this->TypeSynchroPage()];
				$dejaChargee = true;
			}

		   	if ($dejaChargee === false)
		   	{
		   	   	// Si le nombre total d'�l�ments est sup�rieur au nombre d'�l�ments qu'on affiche dans une page de la liste.
		   	   	if ($this->nbElementsParPage < $this->nbElementsTotal)
		   	   		$mListeObjetsMetiers->Charger($this->nbElementsParPage, ($this->numPageCourante - 1) * $this->nbElementsParPage);
		   	   	else
		   		   	$mListeObjetsMetiers->Charger();

		   		// On enregistre le contenu de la liste dans une variable globale aux listes, notamment pour �viter
				// de recharger 2 fois le contenu pour 2 listes identiques.
		   		if (self::$listeElemChargee === NULL)
		   			self::$listeElemChargee = array();
		   		self::$listeElemChargee[$this->TypeSynchroPage()] = $mListeObjetsMetiers->GetListe();
		   	}

		   	if ($listeElem === NULL)
		   		$listeElem = $mListeObjetsMetiers->GetListe();

			// R�cup�ration des �l�ments de la liste m�tier et injection dans la liste graphique.
		   	foreach ($listeElem as $mObjetMetier)
			{
			   	$element = array();
			   	foreach ($this->champs as $nomChamp => &$champ)
			   	{
			   	   	$noms = $nomChamp;
					if (strpos($nomChamp, ',') !== false)
			   	   		$noms = explode(',', $nomChamp);
					$champValeur = $mObjetMetier->GetChampFromTableau($noms);

					if ($champValeur !== NULL)
						$element[$nomChamp][LISTE_ELEMENT_VALEURCONSULT] = $champValeur;
					else
						$element[$nomChamp][LISTE_ELEMENT_VALEURCONSULT] = $this->ChampValeurParDefaut($nomChamp);
			   	}
			   	$this->elements[] = $element;
		   	}
		}
	}

	// Un �l�ment poss�de un ensemble de champs.
	protected function AjouterChamp($nom, $valeurParDefaut = NULL, $estId = false, $retourInvisible = false, $inputModifParDefaut = NULL, $inputCreatParDefaut = NULL, $info = NULL, $erreur = NULL, $autresDonnees = NULL, $enSession = true)
	{
		$champ[] = array();
		// Valeur par d�faut du champ (Utilis� si pas de valeur ou pour les champs non �ditables lors de la cr�ation).
		$champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] = $valeurParDefaut;
		// Est ce que le champ est l'identifiant unique pour l'�l�ment.
		$champ[LISTE_CHAMPLISTE_ESTID] = $estId;
		// Est ce que le champ est invisible et doit �tre retourner en argument aux fonctions ajax.
		$champ[LISTE_CHAMPLISTE_RETOURINVISIBLE] = $retourInvisible;
		// Type de l'input par d�faut du champ pour la modification d'un �l�ment.
		$champ[LISTE_CHAMPLISTE_INPUTMODIFPARDEFAUT] = $inputModifParDefaut;
		// Type de l'input par d�faut du champ pour la cr�ation d'un �l�ment.
		$champ[LISTE_CHAMPLISTE_INPUTCREATPARDEFAUT] = $inputCreatParDefaut;
		// Message d'info qui pop sur les inputs du champ.
		$champ[LISTE_CHAMPLISTE_INFO] = $info;
		// Message d'erreur qui pop sur les inputs du champ.
		$champ[LISTE_CHAMPLISTE_ERREUR] = $erreur;
		// Autres donn�es n�cessaires � la description du champ.
		$champ[LISTE_CHAMPLISTE_AUTRESDONNEES] = $autresDonnees;
		// Doit on mettre la valeur du champ en session pour voir si changement lors d'un rechargement.
		$champ[LISTE_CHAMPLISTE_ENSESSION] = $enSession;

		// Si le nom du champ est un tableau, on le transforme en cha�ne de caract�res.
		$nomChamp = '';
		if (is_array($nom))
		{
			foreach ($nom as $nomCol)
			{
			   	if ($nomChamp !== '')
			   	   	$nomChamp .= ',';
			   	$nomChamp .= $nomCol;
			}
		}
		else
		   	$nomChamp = $nom;
		$this->champs[$nomChamp] = $champ;
	}

	// Remplissage des inputs de type select (select, file, image).
	public function RemplirSelect($element, $nomChamp, $select, $colId = NULL, $colLib = NULL, $colDesc = NULL)
	{
	   	$champ = $this->champs[$nomChamp];
	   	$nomRef = $nomChamp;
	   	if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTDEPENDCHAMP, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
			$nomRef .= '_'.$this->GetElemChampValeurConsultation($element, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_SELECTDEPENDCHAMP]);

		switch ($nomChamp)
		{
			default:
			   	if ($colId !== NULL)
			   		$select->AjouterElementsFromListe($this->contexte.$nomRef, $colId, $colLib, $colDesc);
			   	else
			   	   	$select->AjouterElementsFromListe($this->contexte.$nomRef);
		}
	}

	// R�cup�ration du type de synchro global de la liste.
	public function TypeSynchro()
	{
		return $this->typeSynchro;
	}

	// R�cup�ration du type de synchro complet de la liste.
	public function TypeSynchroPage()
	{
		return $this->typeSynchro.'_p'.$this->numPageCourante;
	}

	// R�cup�ration de l'ancien type de synchro complet de la liste.
	public function AncienTypeSynchroPage()
	{
		return $this->typeSynchro.'_p'.$this->numAnciennePage;
	}

	// R�cup�ration du fait que la page courante a chang�e.
	public function ChangementPage()
	{
		return ($this->numPageCourante !== $this->numAnciennePage);
	}

	// R�cup�ration du nombre de pages.
	public function NbPages()
	{
	   	$nbPages = 1;
	   	if ($this->nbElementsTotal > 0 && $this->nbElementsParPage !== 0)
	   	{
			$nbPages = $this->nbElementsTotal / $this->nbElementsParPage;
			if ($nbPages > intval($nbPages))
				$nbPages = intval($nbPages) + 1;
			else
			   	$nbPages = intval($nbPages);
		}
		return $nbPages;
	}

	// R�cup�ration du num�ro de la liste.
	public function Numero()
	{
		return $this->numero;
	}

	// R�cup�ration de la valeur par d�faut pour le champ.
	protected function ChampValeurParDefaut($nomChamp)
	{
		return $this->champs[$nomChamp][LISTE_CHAMPLISTE_VALEURPARDEFAUT];
	}

	// R�cup�ration du fait que le champ soit le champ identifiant ou non.
	protected function ChampEstId($nomChamp)
	{
		return $this->champs[$nomChamp][LISTE_CHAMPLISTE_ESTID];
	}

	// R�cup�ration du type d'input par d�faut pour le champ lors de la modification d'un �l�ment.
	protected function InputModifParDefaut($nomChamp)
	{
		return $this->champs[$nomChamp][LISTE_CHAMPLISTE_INPUTMODIFPARDEFAUT];
	}

	// R�cup�ration du type d'input par d�faut pour le champ lors de la cr�ation d'un �l�ment.
	protected function InputCreatParDefaut($nomChamp)
	{
		return $this->champs[$nomChamp][LISTE_CHAMPLISTE_INPUTCREATPARDEFAUT];
	}

	// Remplissage de la valeur d'un champ pour un �l�ment.
	protected function SetElemValeurChamp(&$element, $nomChamp, $valeurConsultation = NULL, $valeurModification = NULL)
	{
	   	$element[$nomChamp] = array();

		if ($valeurConsultation !== NULL)
			$element[$nomChamp][LISTE_ELEMENT_VALEURCONSULT] = $valeurConsultation;
		else
			$element[$nomChamp][LISTE_ELEMENT_VALEURCONSULT] = $this->ChampValeurParDefaut($nomChamp);

		if ($valeurModification !== NULL)
			$element[$nomChamp][LISTE_ELEMENT_VALEURMODIF] = $valeurModification;
		else
			$element[$nomChamp][LISTE_ELEMENT_VALEURMODIF] = $this->ChampValeurParDefaut($nomChamp);
	}

	// R�cup�ration de la liste des �l�ments.
	public function GetListeElements()
	{
	   	return $this->elements;
	}

	// R�cup�ration de la liste des menus pour un �l�ment.
	protected function GetElemListeMenus($element)
	{
	   	$menus = array();

	   	if ($this->HasDroitModification($element))
	   	{
	   	   	$this->AjouterMenuToListe($menus, 0, GSession::Libelle(LIB_LIS_MODIFIER, true, true), LISTE_JQFONCTION_MENUPOP.';'.LISTE_JQFONCTION_ETAGEGO, '1;2');
	   	   	$this->AjouterMenuToListe($menus, 1, GSession::Libelle(LIB_LIS_VALIDERMODIFICATION, true, true), $this->foncAjaxModification.';'.LISTE_JQFONCTION_MENUPOP.';'.LISTE_JQFONCTION_ETAGEGO, $element[LISTE_ELEMENT_RETOUR].';0;1', true, LISTE_JQCADRE_ETAGE.'2');
	   	   	$this->AjouterMenuToListe($menus, 1, GSession::Libelle(LIB_LIS_ANNULERMODIFICATION, true, true), LISTE_JQFONCTION_MENUPOP.';'.LISTE_JQFONCTION_ETAGEGO, '0;1');
	   	}
	   	if ($this->HasDroitSuppression($element))
	   	{
	   	   	$this->AjouterMenuToListe($menus, 0, GSession::Libelle(LIB_LIS_SUPPRIMER, true, true), LISTE_JQFONCTION_MENUPOP, 2);
	   	   	$this->AjouterMenuToListe($menus, 2, GSession::Libelle(LIB_LIS_VALIDERSUPPRESSION, true, true), $this->foncAjaxSuppression, $element[LISTE_ELEMENT_RETOUR], true);
	   	   	$this->AjouterMenuToListe($menus, 2, GSession::Libelle(LIB_LIS_ANNULERSUPPRESSION, true, true), LISTE_JQFONCTION_MENUPOP, 0);
	   	}

		return $menus;
	}

	// R�cup�ration de la liste des menus pour l'�l�ment cr�ation.
	protected function GetElemCreationListeMenus()
	{
	   	$menus = array();

	   	if ($this->HasDroitCreation())
	   	   	$this->AjouterMenuToListe($menus, 0, GSession::Libelle(LIB_LIS_CREER, true, true), $this->foncAjaxCreation, 'contexte='.$this->contexte, true, LISTE_JQCADRE_ETAGE.'1', true);

		return $menus;
	}

	// R�cup�ration de la valeur d'un champ pour la consultation de l'�l�ment.
	protected function GetElemChampValeurConsultation($element, $nomChamp, $formatage = false)
	{
	  	return $this->GetElemChampValeur($element, $nomChamp, LISTE_CHAMPTYPE_CONSULT, $formatage);
	}

	// R�cup�ration de la valeur d'un champ pour la modification de l'�l�ment.
	protected function GetElemChampValeurModification($element, $nomChamp, $formatage = false)
	{
	  	return $this->GetElemChampValeur($element, $nomChamp, LISTE_CHAMPTYPE_MODIF, $formatage);
	}

	// R�cup�ration de la valeur d'un champ pour la cr�ation de l'�l�ment.
	protected function GetElemChampValeurCreation($nomChamp)
	{
	  	return $this->GetElemChampValeur(NULL, $nomChamp, LISTE_CHAMPTYPE_CREAT);
	}

	// R�cup�ration de la valeur d'un champ.
	protected function GetElemChampValeur($element, $nomChamp, $type, $formatage = false)
	{
	   	$valeur = NULL;
	   	$champ = $this->champs[$nomChamp];

	   	if ($type === LISTE_CHAMPTYPE_CONSULT && array_key_exists(LISTE_ELEMENT_VALEURCONSULT, $element[$nomChamp]))
	   	{
	   	   	if ($formatage === true && $champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_CHAMPFORMATE, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
			   	$valeur = $this->GetElemChampValeurFormatee($element, $nomChamp, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_CHAMPFORMATE]);
			else
	   	   	   	$valeur = $element[$nomChamp][LISTE_ELEMENT_VALEURCONSULT];
	   	}
	   	else if ($type === LISTE_CHAMPTYPE_MODIF && array_key_exists(LISTE_ELEMENT_VALEURMODIF, $element[$nomChamp]))
	   	   	$valeur = $element[$nomChamp][LISTE_ELEMENT_VALEURMODIF];

	   	$inputParDefaut = NULL;
	   	if ($type === LISTE_CHAMPTYPE_MODIF)
	   		$inputParDefaut = $this->InputModifParDefaut($nomChamp);
	   	else if ($type === LISTE_CHAMPTYPE_CREAT)
	   		$inputParDefaut = $this->InputCreatParDefaut($nomChamp);

	   	// Si on est en mode chargement de la liste pour les parties modification et cr�ation.
	   	if ($valeur === NULL && $inputParDefaut !== NULL)
		{
		   	if (!array_key_exists(LISTE_CHAMPLISTE_INFO, $champ) || $champ[LISTE_CHAMPLISTE_INFO] === NULL)
	   			$champ[LISTE_CHAMPLISTE_INFO] = '';
	   		if (!array_key_exists(LISTE_CHAMPLISTE_ERREUR, $champ) || $champ[LISTE_CHAMPLISTE_ERREUR] === NULL)
	   			$champ[LISTE_CHAMPLISTE_ERREUR] = '';
	   		switch ($inputParDefaut)
			{
			   	case LISTE_INPUTTYPE_SELECT:
	   			   	if (!array_key_exists(LISTE_CHAMPLISTE_VALEURPARDEFAUT, $champ) || $champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] === NULL)
	   			   		$champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] = '';
	   			   	if (!array_key_exists(LISTE_CHAMPLISTE_NONNUL, $champ) || $champ[LISTE_CHAMPLISTE_NONNUL] === NULL)
	   			   		$champ[LISTE_CHAMPLISTE_NONNUL] = false;
	   			   	$rechargeFonc = '';
	   			   	$rechargeParam = '';
	   			   	$type = '';
					if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTDEPENDCHAMP, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
	   			   	{
				   		  $rechargeFonc = AJAXFONC_CHARGERREFERENTIELCONTEXTE;
				   		  $rechargeParam = 'contexte='.$this->contexte;
				   		  $type = $nomChamp;
					}
					$impact = '';
					if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTIMPACT, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
	   			   		$impact = $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_SELECTIMPACT];
	   			   	$colId = COL_ID;
					if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTCOLID, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
	   			   		$colId = $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_SELECTCOLID];
	   				$colLib = array(COL_LIBELLE, COL_LIBELLE);
					if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTCOLLIB, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
	   			   		$colLib = $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_SELECTCOLLIB];
	   			   	$colDesc = '';
					if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTCOLDESC, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
	   			   		$colDesc = $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_SELECTCOLDESC];
					$valeur = new SInputSelect($this->prefixIdClass, INPUTSELECT_TYPE_LISTE, $champ[LISTE_CHAMPLISTE_NONNUL], GContexte::FormaterVariable($this->contexte, $nomChamp), $champ[LISTE_CHAMPLISTE_INFO], $champ[LISTE_CHAMPLISTE_ERREUR], $type, $impact, $rechargeFonc, $rechargeParam);
					$this->RemplirSelect($element, $nomChamp, $valeur, $colId, $colLib, $colDesc);
					break;
				case LISTE_INPUTTYPE_FILE:
	   			   	if (!array_key_exists(LISTE_CHAMPLISTE_VALEURPARDEFAUT, $champ) || $champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] === NULL)
	   			   		$champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] = '';
	   			   	if (!array_key_exists(LISTE_CHAMPLISTE_NONNUL, $champ) || $champ[LISTE_CHAMPLISTE_NONNUL] === NULL)
	   			   		$champ[LISTE_CHAMPLISTE_NONNUL] = false;
	   				$valeur = new SInputFile($this->prefixIdClass, INPUTFILE_TYPE_LISTEFICHIER, $champ[LISTE_CHAMPLISTE_NONNUL], GContexte::FormaterVariable($this->contexte, $nomChamp), $champ[LISTE_CHAMPLISTE_INFO], $champ[LISTE_CHAMPLISTE_ERREUR], '', $this->contexte);
					$this->RemplirSelect($element, $nomChamp, $valeur);
					break;
	   			case LISTE_INPUTTYPE_IMAGE:
	   			   	if (!array_key_exists(LISTE_CHAMPLISTE_VALEURPARDEFAUT, $champ) || $champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] === NULL)
	   			   		$champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] = '';
	   			   	if (!array_key_exists(LISTE_CHAMPLISTE_NONNUL, $champ) || $champ[LISTE_CHAMPLISTE_NONNUL] === NULL)
	   			   		$champ[LISTE_CHAMPLISTE_NONNUL] = false;
	   			   	$typeImage = '';
					if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_IMAGETYPE, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
	   			   		$typeImage = $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_IMAGETYPE];
	   				$valeur = new SInputImage($this->prefixIdClass, INPUTFILE_TYPE_LISTEIMAGE, $champ[LISTE_CHAMPLISTE_NONNUL], GContexte::FormaterVariable($this->contexte, $nomChamp), '', '', $champ[LISTE_CHAMPLISTE_INFO], $champ[LISTE_CHAMPLISTE_ERREUR], $typeImage, $this->contexte);
					$this->RemplirSelect($element, $nomChamp, $valeur);
					break;
	   			case LISTE_INPUTTYPE_TEXT:
	   			   	//if (!array_key_exists(LISTE_CHAMPLISTE_LONGUEURMIN, $champ) || $champ[LISTE_CHAMPLISTE_LONGUEURMIN] === NULL)
	   			   	//	$champ[LISTE_CHAMPLISTE_LONGUEURMIN] = -1;
	   			   	//if (!array_key_exists(LISTE_CHAMPLISTE_LONGUEURMAX, $champ) || $champ[LISTE_CHAMPLISTE_LONGUEURMAX] === NULL)
	   			   	//	$champ[LISTE_CHAMPLISTE_LONGUEURMAX] = -1;
					$taille = $champ[LISTE_CHAMPLISTE_LONGUEURMAX];
					if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_TEXTTAILLE, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
					   	$taille = $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_TEXTTAILLE];
					if (!array_key_exists(LISTE_CHAMPLISTE_REGEXP, $champ) || $champ[LISTE_CHAMPLISTE_REGEXP] === NULL)
						$champ[LISTE_CHAMPLISTE_REGEXP] = '';
	   			   	if (!array_key_exists(LISTE_CHAMPLISTE_VALEURPARDEFAUT, $champ) || $champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] === NULL)
	   			   		$champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] = '';
	   			   	if (!array_key_exists(LISTE_CHAMPLISTE_NONNUL, $champ) || $champ[LISTE_CHAMPLISTE_NONNUL] === NULL)
	   			   		$champ[LISTE_CHAMPLISTE_NONNUL] = false;
	   				$valeur = new SInputText($this->prefixIdClass, INPUTTEXT_TYPE_LISTE, $champ[LISTE_CHAMPLISTE_NONNUL], GContexte::FormaterVariable($this->contexte, $nomChamp), $champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT], $champ[LISTE_CHAMPLISTE_LONGUEURMIN], $champ[LISTE_CHAMPLISTE_LONGUEURMAX], $taille, true, '', $champ[LISTE_CHAMPLISTE_INFO], $champ[LISTE_CHAMPLISTE_ERREUR], $champ[LISTE_CHAMPLISTE_REGEXP], $champ[LISTE_CHAMPLISTE_MIN], $champ[LISTE_CHAMPLISTE_MAX]);
	   				break;
	   			case LISTE_INPUTTYPE_CHECKBOX:
	   			   	$valeurCheck = NULL;
	   			   	if ($element !== NULL)
	   			   	   	$valeurCheck = $this->GetElemChampValeurConsultation($element, $nomChamp);
	   			   	if ($valeurCheck === NULL && (!array_key_exists(LISTE_CHAMPLISTE_VALEURPARDEFAUT, $champ) || $champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT] === NULL))
	   			   		$valeurCheck = false;
	   			   	else if ($valeurCheck === NULL)
	   			   	   	$valeurCheck = $champ[LISTE_CHAMPLISTE_VALEURPARDEFAUT];
	   			   	$valeur = new SInputCheckbox($this->prefixIdClass, INPUTCHECKBOX_TYPE_LISTE, false, GContexte::FormaterVariable($this->contexte, $nomChamp), $champ[LISTE_CHAMPLISTE_INFO], $champ[LISTE_CHAMPLISTE_ERREUR]);
	   			   	$valeur->AjouterCheckbox('', '', $valeurCheck);
			}
	   	}
	   	// Si on est en modification et qu'on n'a pas d'input, on prend la valeur de consultation.
	   	else if ($inputParDefaut === NULL && $type === LISTE_CHAMPTYPE_MODIF)
	   	{
	   	   	if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_CHAMPFORMATE, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
			   	$valeur = $this->GetElemChampValeurFormatee($element, $nomChamp, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_CHAMPFORMATE]);
			else
		       	$valeur = $element[$nomChamp][LISTE_ELEMENT_VALEURCONSULT];
		}
	   	// Si on est en mode rechargement de la liste, on regarde s'il y a des r�f�rentiels � recharger.
	   	else if ($this->rechargement === true && $type === LISTE_CHAMPTYPE_CONSULT)
		{
		   	$inputModif = $this->InputModifParDefaut($nomChamp);
		   	$inputCreat = $this->InputCreatParDefaut($nomChamp);
		   	if ($inputModif === LISTE_INPUTTYPE_SELECT || $inputCreat === LISTE_INPUTTYPE_SELECT)
		   	{
		   	   	$champ = $this->champs[$nomChamp];
			   	$nomRef = $nomChamp;
			   	if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTDEPENDCHAMP, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
					$nomRef .= '_'.$this->GetElemChampValeurConsultation($element, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_SELECTDEPENDCHAMP]);

				$colId = COL_ID;
				if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTCOLID, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
   			   		$colId = $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_SELECTCOLID];
   				$colLib = array(COL_LIBELLE, COL_LIBELLE);
				if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTCOLLIB, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
   			   		$colLib = $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_SELECTCOLLIB];
   			   	$colDesc = '';
				if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTCOLDESC, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
   			   		$colDesc = $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_SELECTCOLDESC];

				GReferentiel::GetDifferentielReferentielForSelect($this->contexte.$nomRef, $colId, $colLib, $colDesc);
		   	}
		   	// Si on est dans le cas d'une liste d'images ou de fichiers.
		   	else if ($inputModif === LISTE_INPUTTYPE_FILE || $inputModif === LISTE_INPUTTYPE_IMAGE || $inputCreat === LISTE_INPUTTYPE_FILE || $inputCreat === LISTE_INPUTTYPE_IMAGE)
			{
			   	$champ = $this->champs[$nomChamp];
			   	$nomRef = $nomChamp;
			   	if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_SELECTDEPENDCHAMP, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
					$nomRef .= '_'.$this->GetElemChampValeurConsultation($element, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES][LISTE_AUTRESDONNEES_SELECTDEPENDCHAMP]);

		   		GReferentiel::GetDifferentielReferentielFichierForSelect($this->contexte.$nomRef);
		   	}
		}

	   	return $valeur;
	}

	// R�cup�ration de la valeur format�e d'un champ.
	protected function GetElemChampValeurFormatee($element, $nomChamp, $format)
	{
	   	$valeur = $element[$nomChamp][LISTE_ELEMENT_VALEURCONSULT];
	   	$valeur = GTexte::Formater($valeur, $format);
	   	return $valeur;
	}

	public function AjouterMenuToListe(&$menus, $numMenu, $libelle, $fonction, $param = '', $ajax = false, $cadre = '', $reset = false)
	{
	   	if (!array_key_exists($numMenu, $menus))
	   	   	$menus[$numMenu] = array();
	   	$nbMenus = count($menus[$numMenu]);
	   	$menus[$numMenu][$nbMenus][LISTE_MENU_ELEMENT_LIB] = $libelle;
	   	$menus[$numMenu][$nbMenus][LISTE_MENU_ELEMENT_FONC] = $fonction;
	   	// On ajoute la cl� de s�curit� des formulaires.
		if ($ajax === true)
		{
	   		if ($param !== '')
	   			$param = '&'.$param;
	   		$param = 'cf='.GSession::NumCheckFormulaire().$param;
	   	}
	   	$menus[$numMenu][$nbMenus][LISTE_MENU_ELEMENT_PARAM] = $param;
	   	$menus[$numMenu][$nbMenus][LISTE_MENU_ELEMENT_CADRE] = $cadre;
	   	$menus[$numMenu][$nbMenus][LISTE_MENU_ELEMENT_AJAX] = $ajax;
	   	$menus[$numMenu][$nbMenus][LISTE_MENU_ELEMENT_RESET] = $reset;
	}

	// Gestion des droits de Consultation. Ce droit peut �tre sp�cifique � un �l�ment.
	protected function HasDroitConsultation($element)
	{
		return true;
	}

	// Gestion des droits de Modification. Ce droit peut �tre sp�cifique � un �l�ment.
	protected function HasDroitModification($element)
	{
		return false;
	}

	// Gestion des droits de Cr�ation. Ce droit n'est pas sp�cifique � un �l�ment.
	protected function HasDroitCreation()
	{
		return false;
	}

	// Gestion des droits de Suppression. Ce droit peut �tre sp�cifique � un �l�ment.
	protected function HasDroitSuppression($element)
	{
		return false;
	}

	// Construction de la ligne de titre de la liste (Noms des colonnes si la liste est organis�e en tableau par exemple).
	protected function ConstruireLigneTitre()
	{
		$elem = new SElement(LISTECLASS_TITRE, false);
	   	$elem->AjouterClasse($this->prefixIdClass.LISTECLASS_TITRE);
		return $elem;
	}

	// Construction de la ligne de changement de page.
	protected function ConstruireChangementPage()
	{
	   	$elem = NULL;

	   	if ($this->nbElementsParPage >= 1)
		{
		   	$elem = new SElemOrg(1, 3, $this->prefixIdClass.INPUTSELECT_LISTE_BARDEF, true, false, false);
		   	$elem->AddClass(LISTE_JQ_PAGE_NAVIGATEUR);
		  	$elem->SetCelluleDominante(1, 2);

		   	// Indicateur premi�re page.
			$elemPremPage = new SElement($this->prefixIdClass.INPUTSELECT_LISTE_BARDEF_HAUT);
	   		$elemPremPage->AjouterClasse(INPUTSELECT_LISTE_BARDEF_HAUT);
	   		$elemPremPage->AddClass(LISTE_JQ_PAGE_PREM);
	   		$elemPremPage->SetText('1');
	   		$elem->AttacherCellule(1, 1, $elemPremPage);

			// Barre de d�filement indicateur de la page courante.
			$elemDef = new SElement($this->prefixIdClass.INPUTSELECT_LISTE_BARDEF);
			$elemDef->AjouterClasse(INPUTSELECT_LISTE_BARDEF);
			$elemDef->AddClass(LISTE_JQ_PAGE_BARREDEFILEMENT);
			$elemDefPrec = new SElement($this->prefixIdClass.INPUTSELECT_LISTE_BARDEF_HAUT);
			$elemDefPrec->AjouterClasse(INPUTSELECT_LISTE_BARDEF_HAUT);
			$elemDefPrec->AddClass(LISTE_JQ_PAGE_PREC);
			$elemDef->Attach($elemDefPrec);
			$divDefBarre = new SBalise(BAL_DIV);
			$elemDefBarre = new SElement($this->prefixIdClass.INPUTSELECT_LISTE_BARDEF_BARRE);
			$elemDefBarre->AjouterClasse(INPUTSELECT_LISTE_BARDEF_BARRE);
			$elemDefBarre->AddClass(LISTE_JQ_PAGE_COURANTE);
			$elemDefBarre->SetText(strval($this->numPageCourante));
			$divDefBarre->Attach($elemDefBarre);
			$elemDef->Attach($divDefBarre);
			$elemDefSuiv = new SElement($this->prefixIdClass.INPUTSELECT_LISTE_BARDEF_BAS);
			$elemDefSuiv->AjouterClasse(INPUTSELECT_LISTE_BARDEF_BAS);
			$elemDefSuiv->AddClass(LISTE_JQ_PAGE_SUIV);
			$elemDef->Attach($elemDefSuiv);
			$elem->AttacherCellule(1, 2, $elemDef);

			// Indicateur derni�re page.
			$elemDerPage = new SElement($this->prefixIdClass.INPUTSELECT_LISTE_BARDEF_HAUT);
	   		$elemDerPage->AjouterClasse(INPUTSELECT_LISTE_BARDEF_HAUT);
	   		$elemDerPage->AddClass(LISTE_JQ_PAGE_DER);
	   		$elemDerPage->SetText(strval($this->NbPages()));
	   		$elem->AttacherCellule(1, 3, $elemDerPage);
	   	}

	   	return $elem;
	}

	// Construction d'un �l�ment de la ligne de titre.
	protected function ConstruireTitreElem($libelle)
	{
		$elem = new SElement(LISTECLASS_TITREELEM, false);
	   	$elem->AjouterClasse($this->prefixIdClass.LISTECLASS_TITREELEM);
	   	$elem->SetText($libelle);
		return $elem;
	}

	// Construction du menu d�roulant d'un �l�ment.
	protected function ConstruireElemMenus($element)
	{
	   	$divMenus = new SBalise(BAL_DIV);
	   	$divMenus->AddClass(LISTE_JQ_ELEMENT_MENUS);

	   	$menus = $this->GetElemListeMenus($element);
	   	foreach ($menus as $menu)
	   	{
	   	   	$divMenu = new SBalise(BAL_DIV);
	   	   	$divMenu->AddClass(LISTE_JQ_ELEMENT_MENU);
	   	   	$divMenus->Attach($divMenu);

	   	   	foreach ($menu as $menuElem)
	   	   	{
	   	   	   	$divMenuElem = new SBalise(BAL_DIV);
	   	   		$divMenuElem->AddClass(LISTE_JQ_ELEMENT_MENUELEM);
	   	   		$divMenu->Attach($divMenuElem);

	   	   		if ($menuElem[LISTE_MENU_ELEMENT_AJAX] === true)
	   	   		   	$divMenuElem->AddClass(LISTE_JQ_ELEMENT_MENUELEM_BOUTONAJAX);

	   	   	   if ($menuElem[LISTE_MENU_ELEMENT_RESET] === true)
	   	   		   	$divMenuElem->AddClass(LISTE_JQ_ELEMENT_MENUELEM_BOUTONRESET);

		   	   	$divMenuElemLib = new SBalise(BAL_DIV);
		   	   	$divMenuElemLib->AddClass(LISTE_JQ_ELEMENT_MENUELEM_LIB);
		   	   	$divMenuElemLib->SetText($menuElem[LISTE_MENU_ELEMENT_LIB]);
		   	   	$divMenuElem->Attach($divMenuElemLib);

		   	   	$divMenuElemFonc = new SBalise(BAL_DIV);
		   	   	$divMenuElemFonc->AddClass(LISTE_JQ_ELEMENT_MENUELEM_BOUTONFONC);
		   	   	$divMenuElemFonc->SetText($menuElem[LISTE_MENU_ELEMENT_FONC]);
		   	   	$divMenuElem->Attach($divMenuElemFonc);

		   	   	$divMenuElemParam = new SBalise(BAL_DIV);
		   	   	$divMenuElemParam->AddClass(LISTE_JQ_ELEMENT_MENUELEM_BOUTONPARAM);
		   	   	$divMenuElemParam->SetText(to_html(strval($menuElem[LISTE_MENU_ELEMENT_PARAM])));
		   	   	$divMenuElem->Attach($divMenuElemParam);

		   		$divMenuElemCadre = new SBalise(BAL_DIV);
		   	   	$divMenuElemCadre->AddClass(LISTE_JQ_ELEMENT_MENUELEM_BOUTONCADRE);
		   	   	$divMenuElemCadre->SetText(strval($menuElem[LISTE_MENU_ELEMENT_CADRE]));
		   	   	$divMenuElem->Attach($divMenuElemCadre);
		   	}
		}

	   	return $divMenus;
	}

	// Construction des champs d'un �l�ment.
	protected function ConstruireElemChamps(&$element)
	{
	   	$divChamps = new SBalise(BAL_DIV);
	   	$divChamps->AddClass(LISTE_JQ_ELEMENT_CHAMPS);

	   	// Premier chargement de la liste.
	   	if ($this->rechargement === false)
		  	  $this->ConstruireElemChampsPourCreation($element, $divChamps);
		// Rechargement.
		else
		{
		   	// Cr�ation.
		   	if (!array_key_exists($element[LISTE_ELEMENT_ID], $this->listeContexte) || !array_key_exists(LISTE_CONTEXTE_CHAMPS, $this->listeContexte[$element[LISTE_ELEMENT_ID]]))
			   	$this->ConstruireElemChampsPourCreation($element, $divChamps);
		   	// Modification.
			else
		  	   	$this->ConstruireElemChampsPourModification($element, $divChamps);

		   	// On enl�ve l'�l�ment de la liste des �l�ments supprim�s.
		   	unset($this->listeSuppressions[$element[LISTE_ELEMENT_ID]]);
		}

	   	return $divChamps;
	}

	// Construction des champs d'un �l�ment qui n'existe pas encore dans la liste.
	protected function ConstruireElemChampsPourCreation(&$element, $divChamps)
	{
	   	$element[LISTE_ELEMENT_ACTION] = LISTE_ELEMACTION_CREAT;

	   	// On commence par les champs de modification.
	   	if ($this->chargementModifDiffere === false)
	   	   	$this->ConstruireElemEtageChampsPourCreation($element, $divChamps, LISTE_ETAGE_MODIF);

		// On poursuit par les champs de consulation.
		$this->ConstruireElemEtageChampsPourCreation($element, $divChamps, LISTE_ETAGE_CONSULT);
	}

	// Construction des champs modifi�s d'un �l�ment qui existe d�j� dans la liste.
	protected function ConstruireElemChampsPourModification(&$element, $divChamps)
	{
	   	$element[LISTE_ELEMENT_ACTION] = LISTE_ELEMACTION_MODIF;
	   	$forcageRechargement = false;

		// On commence par les champs de modification si on charge l'�tage de modification.
		if (self::$chargementEtage !== NULL && self::$chargementEtage !== '')
	   	{
		    if (array_key_exists(intval(LISTE_ETAGE_MODIF), self::$chargementEtage[$this->TypeSynchro()][$this->numero]))
			{
			 	if (self::$chargementEtage[$this->TypeSynchro()][$this->numero][intval(LISTE_ETAGE_MODIF)] == $element[LISTE_ELEMENT_ID])
				{
				   	$element[LISTE_ELEMENT_MODIFIE] = true;
				   	$forcageRechargement = true;
				   	$this->ConstruireElemEtageChampsPourCreation($element, $divChamps, LISTE_ETAGE_MODIF);
				}
			}
		}

		// On poursuit par les champs pour la mise � jour standard.
		$this->ConstruireElemEtageChampsPourModification($element, $divChamps, -1, $forcageRechargement);
	}

	// Construction des champs d'un �l�ment qui n'existe pas encore dans la liste pour un �tage donn�.
	protected function ConstruireElemEtageChampsPourCreation(&$element, $divChamps, $etage)
	{
	   	switch ($etage)
		{
	   		case LISTE_ETAGE_CONSULT:
	   			foreach ($this->champs as $nomChamp => $champ)
			   	{
			   	   	$valeurConsult = $this->GetElemChampValeurConsultation($element, $nomChamp, true);

					// On met � jour le contexte de la liste pour le champ de l'�l�ment.
					if (!array_key_exists($element[LISTE_ELEMENT_ID], $this->listeContexte))
						$this->listeContexte[$element[LISTE_ELEMENT_ID]] = array();
					if (!array_key_exists(LISTE_CONTEXTE_CHAMPS, $this->listeContexte[$element[LISTE_ELEMENT_ID]]))
					   	$this->listeContexte[$element[LISTE_ELEMENT_ID]][LISTE_CONTEXTE_CHAMPS] = array();

					if ($champ[LISTE_CHAMPLISTE_ENSESSION] === true)
					   	$this->listeContexte[$element[LISTE_ELEMENT_ID]][LISTE_CONTEXTE_CHAMPS][$nomChamp] = $valeurConsult;

					if ($valeurConsult !== NULL)
					{
				   	   	$divChamp = new SBalise(BAL_DIV);
				   	   	$divChamp->AddClass(LISTE_JQ_ELEMENT_CHAMP);
					   	$divChamps->Attach($divChamp);

				  	  	$divChampValeur = new SBalise(BAL_DIV);
				   	   	$divChampValeur->AddClass(LISTE_JQ_ELEMENT_CHAMP_VALEUR);
				   	   	$divChamp->Attach($divChampValeur);
					   	if (is_bool($valeurConsult))
						{
							$checkbox = new SInputCheckbox($this->prefixIdClass, INPUTCHECKBOX_TYPE_LISTE);
			   			   	$checkbox->AjouterCheckbox('', '', $valeurConsult);
			   			   	$divChampValeur->Attach($checkbox);
					   	}
					   	else if ($this->InputModifParDefaut($nomChamp) === LISTE_INPUTTYPE_IMAGE)
						{
						   	$divImg = new SBalise(BAL_DIV);
						   	$img = NULL;
							if ($valeurConsult === '')
						   		$img = new SImage('');
						   	else
						   	   	$img = new SImage($valeurConsult);
						   	$divImg->Attach($img);
					   		$divChampValeur->Attach($divImg);
					   	}
						else if (is_string($valeurConsult) || is_int($valeurConsult))
						    $divChampValeur->SetText(strval($valeurConsult));
			   	   		else
			   	   		   	$divChampValeur->Attach($valeurConsult);

			   	   		$divChampNom = new SBalise(BAL_DIV);
				   	   	$divChampNom->AddClass(LISTE_JQ_ELEMENT_CHAMP_NOM);
				   	   	if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_CHAMPFORMATE, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
				   	   		$divChampNom->SetText($nomChamp.'_f');
				   	   	else
						   	$divChampNom->SetText($nomChamp);
				   	   	$divChamp->Attach($divChampNom);

				   	   	$divChampType = new SBalise(BAL_DIV);
				   	   	$divChampType->AddClass(LISTE_JQ_ELEMENT_CHAMP_TYPE);
				   	   	$divChampType->SetText(LISTE_CHAMPTYPE_CONSULT);
				   	   	$divChamp->Attach($divChampType);
			   	   	}
				}
	   			break;
	   		case LISTE_ETAGE_MODIF:
	   			foreach ($this->champs as $nomChamp => $champ)
			   	{
			   	   	$valeurModif = $this->GetElemChampValeurModification($element, $nomChamp);
			   	   	if ($valeurModif !== NULL)
					{
				   	   	$divChamp = new SBalise(BAL_DIV);
				   	   	$divChamp->AddClass(LISTE_JQ_ELEMENT_CHAMP);
					   	$divChamps->Attach($divChamp);

				  	  	$divChampValeur = new SBalise(BAL_DIV);
				   	   	$divChampValeur->AddClass(LISTE_JQ_ELEMENT_CHAMP_VALEUR);
				   	   	$divChamp->Attach($divChampValeur);
					   	if (is_string($valeurModif) || is_int($valeurModif))
						    $divChampValeur->SetText(strval($valeurModif));
			   	   		else
			   	   		   	$divChampValeur->Attach($valeurModif);

			   	   		$divChampNom = new SBalise(BAL_DIV);
				   	   	$divChampNom->AddClass(LISTE_JQ_ELEMENT_CHAMP_NOM);
				   	   	$divChampNom->SetText($nomChamp);
				   	   	$divChamp->Attach($divChampNom);

				   	   	$divChampType = new SBalise(BAL_DIV);
				   	   	$divChampType->AddClass(LISTE_JQ_ELEMENT_CHAMP_TYPE);
				   	   	$divChampType->SetText(LISTE_CHAMPTYPE_MODIF);
				   	   	$divChamp->Attach($divChampType);
			   	   	}
				};
	   			break;
	   	}
	}

	// Construction des champs modifi�s d'un �l�ment qui existe d�j� dans la liste pour un �tage donn�.
	protected function ConstruireElemEtageChampsPourModification(&$element, $divChamps, $etage, $forcageRechargement = false)
	{
	   	switch ($etage)
		{
	   		default:
	   		   	foreach ($this->champs as $nomChamp => $champ)
			   	{
			   	   	if (array_key_exists($nomChamp, $this->listeContexte[$element[LISTE_ELEMENT_ID]][LISTE_CONTEXTE_CHAMPS]))
					{
					   	$valeurConsultContexte = NULL;
					   	if ($champ[LISTE_CHAMPLISTE_ENSESSION] === true)
				   	   	   	$valeurConsultContexte = $this->listeContexte[$element[LISTE_ELEMENT_ID]][LISTE_CONTEXTE_CHAMPS][$nomChamp];
				   	   	$valeurConsult = $this->GetElemChampValeurConsultation($element, $nomChamp);
				   	   	// Si la nouvelle valeur est diff�rente de celle en session ou que la valeur n'existe pas en session.
				   	   	if ($valeurConsult !== NULL && (($valeurConsult != $valeurConsultContexte && $valeurConsultContexte !== NULL) || $valeurConsultContexte === NULL || $forcageRechargement === true))
						{
						   	// L'�l�ment a �t� modifi�.
						   	$element[LISTE_ELEMENT_MODIFIE] = true;

						   	// Mise � jour du contexte de la liste pour le champ de l'�l�ment.
						   	if ($champ[LISTE_CHAMPLISTE_ENSESSION] === true)
						   	   	$this->listeContexte[$element[LISTE_ELEMENT_ID]][LISTE_CONTEXTE_CHAMPS][$nomChamp] = $valeurConsult;

					   	   	$divChamp = new SBalise(BAL_DIV);
					   	   	$divChamp->AddClass(LISTE_JQ_ELEMENT_CHAMP);
					   	   	$divChamps->Attach($divChamp);

					  	  	$divChampValeur = new SBalise(BAL_DIV);
					   	   	$divChampValeur->AddClass(LISTE_JQ_ELEMENT_CHAMP_VALEUR);
					   	   	$divChamp->Attach($divChampValeur);
					   	   	if ($this->InputModifParDefaut($nomChamp) === LISTE_INPUTTYPE_IMAGE)
					   		{
					   		   	if ($valeurConsult === '')
					   		   		$divChampValeur->SetText('');
					   		   	else
							   	   	$divChampValeur->SetText(PATH_SERVER_HTTP.$valeurConsult);
							}
						   	else if (is_string($valeurConsult))
							{
							   	// Cas o� le champ est format�, on doit mettre � jour le champ non format� et le champ format�.
							   	if ($champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_CHAMPFORMATE, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
							   	{
							   	   	$dChamp = new SBalise(BAL_DIV);
							   	   	$dChamp->AddClass(LISTE_JQ_ELEMENT_CHAMP);
							   	   	$divChamps->Attach($dChamp);

							  	  	$dChampValeur = new SBalise(BAL_DIV);
							   	   	$dChampValeur->AddClass(LISTE_JQ_ELEMENT_CHAMP_VALEUR);
							   	   	$dChamp->Attach($dChampValeur);
								   	$val = $this->GetElemChampValeurConsultation($element, $nomChamp, true);
									$dChampValeur->SetText($val);

									$dChampNom = new SBalise(BAL_DIV);
							   	   	$dChampNom->AddClass(LISTE_JQ_ELEMENT_CHAMP_NOM);
							   	   	$dChampNom->SetText($nomChamp.'_f');
							   	   	$dChamp->Attach($dChampNom);

							   	   	$dChampType = new SBalise(BAL_DIV);
							   	   	$dChampType->AddClass(LISTE_JQ_ELEMENT_CHAMP_TYPE);
							   	   	$dChampType->SetText(LISTE_CHAMPTYPE_CONSULT);
							   	   	$dChamp->Attach($dChampType);
								}
								$divChampValeur->SetText($valeurConsult);
							}
							else if (is_int($valeurConsult) || is_bool($valeurConsult))
						   	{
						   	   	if ($valeurConsult === true)
				   	   		   		$valeurConsult = '1';
				   	   		   	else if ($valeurConsult === false)
									$valeurConsult = '0';
							    $divChampValeur->SetText(strval($valeurConsult));
							}
				   	   		else
				   	   		   	$divChampValeur->Attach($valeurConsult);

				   	   		$divChampNom = new SBalise(BAL_DIV);
					   	   	$divChampNom->AddClass(LISTE_JQ_ELEMENT_CHAMP_NOM);
					   	   	$divChampNom->SetText($nomChamp);
					   	   	$divChamp->Attach($divChampNom);

					   	   	$divChampType = new SBalise(BAL_DIV);
					   	   	$divChampType->AddClass(LISTE_JQ_ELEMENT_CHAMP_TYPE);
					   	   	$divChampType->SetText(LISTE_CHAMPTYPE_CONSULT);
					   	   	$divChamp->Attach($divChampType);
				   	   	}
				   	}
				}
				break;
	   	}
	}

	// Construction de l'�l�ment en consultation.
	protected function ConstruireElemConsultation()
	{
	   	$elem = new SElement(LISTECLASS_ELEMCONSULT, false);
	   	$elem->AjouterClasse($this->prefixIdClass.LISTECLASS_ELEMCONSULT);
		return $elem;
	}

	// Construction de l'�l�ment en modification.
	protected function ConstruireElemModification()
	{
		$elem = new SElement(LISTECLASS_ELEMMODIF, false);
	   	$elem->AjouterClasse($this->prefixIdClass.LISTECLASS_ELEMMODIF);
		return $elem;
	}

	// Construction de l'�l�ment en cr�ation.
	protected function ConstruireElemCreation()
	{
		$elem = new SElement(LISTECLASS_ELEMCREAT, false);
	   	$elem->AjouterClasse($this->prefixIdClass.LISTECLASS_ELEMCREAT);
		return $elem;
	}

	// Construction d'un champ de l'�l�ment.
	protected function ConstruireChamp($nom, $typeChamp = LISTE_CHAMPTYPE_CONSULT)
	{
		$elem = new SElement(LISTECLASS_ELEMCHAMP, false);
	   	$elem->AjouterClasse($this->prefixIdClass.LISTECLASS_ELEMCHAMP);
	   	$elem->AddClass(LISTE_JQ_ELEM_CHAMP);

	   	// Si le nom du champ est un tableau, on le transforme en cha�ne de caract�res.
		$nomChamp = '';
		if (is_array($nom))
		{
			foreach ($nom as $nomCol)
			{
			   	if ($nomChamp !== '')
			   	   	$nomChamp .= ',';
			   	$nomChamp .= $nomCol;
			}
		}
		else
		   	$nomChamp = $nom;

	   	if ($typeChamp === LISTE_CHAMPTYPE_CREAT)
		{
	   		$elemCreat = $this->GetElemChampValeurCreation($nomChamp);
	   		if ($elemCreat !== NULL)
	   			$elem->Attach($elemCreat);
	   	}
	   	else
	   	{
		   	$divChampNom = new SBalise(BAL_DIV);
	   	   	$divChampNom->AddClass(LISTE_JQ_ELEM_CHAMP_NOM);
	   	   	$champ = $this->champs[$nomChamp];
			if ($typeChamp === LISTE_CHAMPTYPE_CONSULT && $champ[LISTE_CHAMPLISTE_AUTRESDONNEES] !== NULL && array_key_exists(LISTE_AUTRESDONNEES_CHAMPFORMATE, $champ[LISTE_CHAMPLISTE_AUTRESDONNEES]))
			   	$divChampNom->SetText($nomChamp.'_f');
	   	   	else
			   	$divChampNom->SetText($nomChamp);
	   	   	$elem->Attach($divChampNom);

	   	   	$divChampType = new SBalise(BAL_DIV);
	   	   	$divChampType->AddClass(LISTE_JQ_ELEM_CHAMP_TYPE);
	   	   	$divChampType->SetText($typeChamp);
	   	   	$elem->Attach($divChampType);
	   	}

		return $elem;
	}

	// Construction du menu de l'�l�ment.
	protected function ConstruireElemMenu()
	{
		$elem = new SElement(LISTECLASS_ELEMMENU, false);
	   	$elem->AjouterClasse($this->prefixIdClass.LISTECLASS_ELEMMENU);
	   	$elem->AddClass(LISTE_JQ_ELEM_MENU);

	   	$divMenu = new SBalise(BAL_DIV);
	   	$divMenu->AddClass(LISTE_JQ_ELEM_MENUELEM);
	   	$elem->Attach($divMenu);

		$elemMenu = new SElement(LISTECLASS_ELEMMENU_ELEM, false);
	   	$elemMenu->AjouterClasse($this->prefixIdClass.LISTECLASS_ELEMMENU_ELEM);
	   	$elemMenu->AddClass(LISTE_JQ_ELEM_MENUELEM_BOUTON);
		$divMenu->Attach($elemMenu);

		return $elem;
	}

	// Construction du menu de l'�l�ment cr�ation.
	protected function ConstruireElemCreationMenu()
	{
		$elemMenus = array();

	   	foreach ($this->GetElemCreationListeMenus() as $menu)
	   	{
	   	   	$elem = new SElement(LISTECLASS_ELEMMENU, false);
	   		$elem->AjouterClasse($this->prefixIdClass.LISTECLASS_ELEMMENU);
	   		$elem->AddClass(LISTE_JQ_ELEM_MENU);
	   	   	$elemMenus[] = $elem;

	   	   	foreach ($menu as $menuElem)
	   	   	{
	   	   	   	$divMenuElem = new SBalise(BAL_DIV);
			   	$divMenuElem->AddClass(LISTE_JQ_ELEM_MENUELEM);
			   	$elem->Attach($divMenuElem);

	   	   		if ($menuElem[LISTE_MENU_ELEMENT_AJAX] === true)
	   	   		   	$divMenuElem->AddClass(LISTE_JQ_ELEMENT_MENUELEM_BOUTONAJAX);

	   	   	   if ($menuElem[LISTE_MENU_ELEMENT_RESET] === true)
	   	   		   	$divMenuElem->AddClass(LISTE_JQ_ELEMENT_MENUELEM_BOUTONRESET);

		   	   	$divMenuElemFonc = new SBalise(BAL_DIV);
		   	   	$divMenuElemFonc->AddClass(LISTE_JQ_ELEMENT_MENUELEM_BOUTONFONC);
		   	   	$divMenuElemFonc->SetText($menuElem[LISTE_MENU_ELEMENT_FONC]);
		   	   	$divMenuElem->Attach($divMenuElemFonc);

		   	   	$divMenuElemParam = new SBalise(BAL_DIV);
		   	   	$divMenuElemParam->AddClass(LISTE_JQ_ELEMENT_MENUELEM_BOUTONPARAM);
		   	   	$divMenuElemParam->SetText(to_html(strval($menuElem[LISTE_MENU_ELEMENT_PARAM])));
		   	   	$divMenuElem->Attach($divMenuElemParam);

		   		$divMenuElemCadre = new SBalise(BAL_DIV);
		   	   	$divMenuElemCadre->AddClass(LISTE_JQ_ELEMENT_MENUELEM_BOUTONCADRE);
		   	   	$divMenuElemCadre->SetText(strval($menuElem[LISTE_MENU_ELEMENT_CADRE]));
		   	   	$divMenuElem->Attach($divMenuElemCadre);

		   	   	$elemMenu = new SElement(LISTECLASS_ELEMMENU_ELEM, false);
			   	$elemMenu->AjouterClasse($this->prefixIdClass.LISTECLASS_ELEMMENU_ELEM);
			   	$elemMenu->AddClass(LISTE_JQ_ELEM_MENUELEM_BOUTON);
			   	$elemMenu->SetText($menuElem[LISTE_MENU_ELEMENT_LIB]);
				$divMenuElem->Attach($elemMenu);
		   	}
		}

		return $elemMenus;
	}

	// Construction de la partie triable de la liste si elle l'est.
	protected function ConstruireListeTriable()
	{
	   	// Est ce que la liste est triable (drag and drop des �l�ments).
		if ($this->triable === true)
		{
			$this->AddClass(LISTE_JQ_SORTABLE);

			// Construction du type de la liste (utilis� pour les �changes d'�l�ments dans les listes triables).
			$divType = new SBalise(BAL_DIV);
			$divType->AddClass(LISTE_JQ_TYPE);
			$divType->SetText($this->typeLiaison);
			$this->Attach($divType);

			if ($this->foncAjaxTriModification !== '')
			{
				// Construction de la fonction appel�e quand un �l�ment est drag and drop� � l'int�rieur de la liste.
				$divFoncInIn = new SBalise(BAL_DIV);
				$divFoncInIn->AddClass(LISTE_JQ_SORTABLE_FONCININ);
				$divFoncInIn->AddProp(PROP_STYLE, 'display:none');
				$divFoncInIn->SetText($this->foncAjaxTriModification);
				$this->Attach($divFoncInIn);
			}

			if ($this->foncAjaxTriCreation !== '')
			{
				// Construction de la fonction appel�e quand un �l�ment est drag and drop� de l'ext�rieur vers l'int�rieur la liste.
				$divFoncOutIn = new SBalise(BAL_DIV);
				$divFoncOutIn->AddClass(LISTE_JQ_SORTABLE_FONCOUTIN);
				$divFoncOutIn->AddProp(PROP_STYLE, 'display:none');
				$divFoncOutIn->SetText($this->foncAjaxTriCreation);
				$this->Attach($divFoncOutIn);
			}

			if ($this->foncAjaxTriSuppression !== '')
			{
				// Construction de la fonction appel�e quand un �l�ment est drag and drop� de l'int�rieur vers l'ext�rieur de la liste.
				$divFoncInOut = new SBalise(BAL_DIV);
				$divFoncInOut->AddClass(LISTE_JQ_SORTABLE_FONCINOUT);
				$divFoncInOut->AddProp(PROP_STYLE, 'display:none');
				$divFoncInOut->SetText($this->foncAjaxTriSuppression);
				$this->Attach($divFoncInOut);
			}
		}
	}

	// Construction de la partie triable de l'�l�ment si la liste l'est.
	protected function ConstruireElemTriable($elem, $element)
	{
	   	// Est ce que la liste est triable (drag and drop des �l�ments).
		if ($this->triable === true)
		{
		   	$param = $element[LISTE_ELEMENT_RETOUR];
		   	if ($param !== '')
	   			$param = '&'.$param;
	   		$param = 'cf='.GSession::NumCheckFormulaire().$param;

			if ($this->foncAjaxTriModification !== '')
			{
				// Construction des param�tres de la fonction appel�e quand un �l�ment est drag and drop� � l'int�rieur de la liste.
				$divParamInIn = new SBalise(BAL_DIV);
				$divParamInIn->AddClass(LISTE_JQ_SORTABLE_PARAMININ);
				$divParamInIn->AddProp(PROP_STYLE, 'display:none');
				$divParamInIn->SetText(to_html($param.'&'.$this->contexte.'[Ordre]='));
				$elem->Attach($divParamInIn);
			}

			if ($this->foncAjaxTriCreation !== '')
			{
				// Construction des param�tres de la fonction appel�e quand un �l�ment est drag and drop� de l'ext�rieur vers l'int�rieur la liste.
				$divParamOutIn = new SBalise(BAL_DIV);
				$divParamOutIn->AddClass(LISTE_JQ_SORTABLE_PARAMOUTIN);
				$divParamInIn->AddProp(PROP_STYLE, 'display:none');
				$divParamOutIn->SetText(to_html($param.'&'.$this->contexte.'[Ordre]='));
				$elem->Attach($divParamOutIn);
			}

			if ($this->foncAjaxTriSuppression !== '')
			{
				// Construction des param�tres de la fonction appel�e quand un �l�ment est drag and drop� de l'int�rieur vers l'ext�rieur de la liste.
				$divParamInOut = new SBalise(BAL_DIV);
				$divParamInOut->AddClass(LISTE_JQ_SORTABLE_PARAMINOUT);
				$divParamInIn->AddProp(PROP_STYLE, 'display:none');
				$divParamInOut->SetText(to_html($param.'&'.$this->contexte.'[Ordre]='));
				$elem->Attach($divParamInOut);
			}
		}
	}

	// Construction des arguments invisibles de l'�l�ment.
	protected function ConstruireElemRetourInvisible(&$element)
	{
	   	$retourInvisible = '';

	   	if ($this->contexte != '')
	   	   	$retourInvisible = 'contexte='.$this->contexte;

	   	foreach($this->champs as $nomChamp => $champ)
		{
	   		if ($champ[LISTE_CHAMPLISTE_RETOURINVISIBLE] === true)
			{
			   	if ($retourInvisible !== '')
			   		$retourInvisible .= '&';
			   	if ($this->contexte == '')
	   			   	$retourInvisible .= $nomChamp.'='.$element[$nomChamp][LISTE_ELEMENT_VALEURCONSULT];
	   			else
	   			   	$retourInvisible .= GContexte::FormaterVariable($this->contexte, $nomChamp).'='.$element[$nomChamp][LISTE_ELEMENT_VALEURCONSULT];
	   		}
	   	}

	   	// On enregistre ce retour pour l'�l�ment.
	   	$element[LISTE_ELEMENT_RETOUR] = to_html($retourInvisible);

	   	$divRetInv = new SBalise(BAL_DIV);
	   	$divRetInv->AddClass(LISTE_JQ_ELEMENT_PARAM);
	   	$divRetInv->SetText($element[LISTE_ELEMENT_RETOUR]);
	   	return $divRetInv;
	}

	// Construction de l'id de l'�l�ment.
	protected function ConstruireElemId(&$element)
	{
	   	$id = '';
	   	foreach($this->champs as $nomChamp => $champ)
		{
	   		if ($champ[LISTE_CHAMPLISTE_ESTID] === true)
			{
			   	if ($id !== '')
			   		$id .= '_';
	   			$id .= $element[$nomChamp][LISTE_ELEMENT_VALEURCONSULT];
	   		}
	   	}

	   	// On enregistre l'id pour l'�l�ment.
	   	$element[LISTE_ELEMENT_ID] = to_html(strval($id));

	   	$divId = new SBalise(BAL_DIV);
	   	$divId->AddClass(LISTE_JQ_ELEMENT_ID);
	   	$divId->SetText($element[LISTE_ELEMENT_ID]);
	   	return $divId;
	}

	// Construction de l'ordre de l'�l�ment.
	protected function ConstruireElemOrdre(&$element, $ordre)
	{
	   	// On enregistre l'ordre pour l'�l�ment.
	   	$element[LISTE_ELEMENT_ORDRE] = strval($ordre);

	   	if (!array_key_exists($element[LISTE_ELEMENT_ID], $this->listeContexte))
			$this->listeContexte[$element[LISTE_ELEMENT_ID]] = array();
	   	if (array_key_exists(LISTE_CONTEXTE_ORDRE, $this->listeContexte[$element[LISTE_ELEMENT_ID]]) && $ordre !== $this->listeContexte[$element[LISTE_ELEMENT_ID]][LISTE_CONTEXTE_ORDRE])
	   		$element[LISTE_ELEMENT_MODIFIE] = true;

		$this->listeContexte[$element[LISTE_ELEMENT_ID]][LISTE_CONTEXTE_ORDRE] = $ordre;

	   	$divOrdre = new SBalise(BAL_DIV);
	   	$divOrdre->AddClass(LISTE_JQ_ELEMENT_ORDRE);
	   	$divOrdre->SetText($element[LISTE_ELEMENT_ORDRE]);
	   	return $divOrdre;
	}

	// Construction d'un �l�ment avec v�rification des droits.
	public function ConstruireElement(&$element, $ordre)
	{
		$elem = new SBalise(BAL_DIV);
		$elem->AddClass(LISTE_JQ_ELEMENT);

		$divId = $this->ConstruireElemId($element);
		$elem->Attach($divId);

		$divOrdre = $this->ConstruireElemOrdre($element, $ordre);
		$elem->Attach($divOrdre);

		$divChamps = $this->ConstruireElemChamps($element);
		$elem->Attach($divChamps);

		if ($this->rechargement === false || $element[LISTE_ELEMENT_ACTION] === LISTE_ELEMACTION_CREAT)
		{
		   	$divRetInv = $this->ConstruireElemRetourInvisible($element);
			$elem->Attach($divRetInv);

			// Construction de la partie triable de l'�l�ment si la liste l'est.
			$this->ConstruireElemTriable($elem, $element);

			$divMenus = $this->ConstruireElemMenus($element);
			$elem->Attach($divMenus);
		}

		return $elem;
	}

	// Construction d'un �l�ment qui permet de cr�er un nouvel �l�ment dans la liste.
	public function ConstruireElementCreation()
	{
	   	$elem = NULL;

		// Cr�ation.
		$divCreat = new SBalise(BAL_DIV);
		$divCreat->AddClass(LISTE_JQ_ELEM_ETAGE);
		$elemCreat = $this->ConstruireElemCreation();
		if ($elemCreat !== NULL)
		{
		   	$divEtageCreat = new SBalise(BAL_DIV);
			$divEtageCreat->AddClass(LISTE_JQ_ELEM_ETAGE_NUM);
			$divEtageCreat->SetText('1');
			$divCreat->Attach($divEtageCreat);
			$divCreat->Attach($elemCreat);
		}

		// Menu.
		$divMenu = new SBalise(BAL_DIV);
		$divMenu->AddClass(LISTE_JQ_ELEM_MENUS);
		$divMenu->AddProp(PROP_STYLE, 'display: none;');
		foreach ($this->ConstruireElemCreationMenu() as $elemMenu)
		{
			$divMenu->Attach($elemMenu);
		}

		if ($elemCreat !== NULL)
		{
			$elem = new SElemOrg(1, 2, $this->prefixIdClass.LISTECLASS_ELEMENT, true, false, false);
		   	$elem->AjouterClasse(LISTECLASS_ELEMENT);
		   	$elem->AddClass(LISTE_JQ_ELEMENTCREATION);
		   	$elem->SetCelluleDominante(1, 1);
		   	$elem->AttacherCellule(1, 1, $divCreat);
			$elem->AttacherCellule(1, 2, $divMenu);
		}
		else
		   	GLog::LeverException(EXS_0000, 'SListe::ConstruireElementCreation, la liste de type ['.$this->TypeSynchro().'] n\'a pas d\'�l�ment cr�ation pour le contexte ['.$this->contexte.'].');

		return $elem;
	}

	// Construction d'un �l�ment mod�le � partir duquel vont �tre fabriqu�s tous les autres �l�ments (via le JS).
	public function ConstruireElementModele()
	{
	   	$elem = NULL;

		// Consultation.
		$divConsult = new SBalise(BAL_DIV);
		$divConsult->AddClass(LISTE_JQ_ELEM_ETAGE);
		$elemConsult = $this->ConstruireElemConsultation();
		if ($elemConsult !== NULL)
		{
		   	$divEtageConsult = new SBalise(BAL_DIV);
			$divEtageConsult->AddClass(LISTE_JQ_ELEM_ETAGE_NUM);
			$divEtageConsult->SetText('1');
			$divConsult->Attach($divEtageConsult);
			$divConsult->Attach($elemConsult);
		}

		// Modification.
	   	$divModif = new SBalise(BAL_DIV);
	   	$divModif->AddClass(LISTE_JQ_ELEM_ETAGE);
		$elemModif = $this->ConstruireElemModification();
		if ($elemModif !== NULL)
		{
			$divEtageModif = new SBalise(BAL_DIV);
			$divEtageModif->AddClass(LISTE_JQ_ELEM_ETAGE_NUM);
			$divEtageModif->SetText('2');
			$divModif->Attach($divEtageModif);

			if ($this->chargementModifDiffere === true)
			{
				// Construction de la fonction de chargement du contenu de l'�tage.
			   	$divChargePageFonc = new SBalise(BAL_DIV);
			   	$divChargePageFonc->AddClass(LISTE_JQ_ELEM_ETAGE_CHARGEFONC);
			   	$divChargePageFonc->SetText($this->foncAjaxRechargement);
			   	$divModif->Attach($divChargePageFonc);

			   	// Construction des param�tres pour la fonction de chargement du contenu de l'�tage.
			   	$divChargePageParam = new SBalise(BAL_DIV);
			   	$divChargePageParam->AddClass(LISTE_JQ_ELEM_ETAGE_CHARGEPARAM);
			   	$param = 'contexte='.$this->contexte.'&'.$this->contexte.'[etage]['.$this->TypeSynchro().']['.$this->Numero().'][2]';
			   	$divChargePageParam->SetText(to_html($param));
			   	$divModif->Attach($divChargePageParam);
			}

			$divModif->Attach($elemModif);
		}

		// Menu.
		$divMenu = new SBalise(BAL_DIV);
		$divMenu->AddClass(LISTE_JQ_ELEM_MENUS);
		$divMenu->AddProp(PROP_STYLE, 'display: none;');
		$elemMenu = $this->ConstruireElemMenu();
		if ($elemMenu !== NULL)
			$divMenu->Attach($elemMenu);

		if ($elemConsult !== NULL && $elemModif !== NULL)
		{
			$elem = new SElemOrg(2, 2, $this->prefixIdClass.LISTECLASS_ELEMENT, true, false, false);
		   	$elem->AjouterClasse(LISTECLASS_ELEMENT);
		   	$elem->AddClass(LISTE_JQ_ELEMENTMODELE);
		   	$elem->FusionnerCellule(1, 2, 1, 0);
		   	$elem->SetCelluleDominante(1, 1);
		   	$elem->AttacherCellule(1, 1, $divConsult);
			$elem->AttacherCellule(2, 1, $divModif);
			$elem->AttacherCellule(1, 2, $divMenu);
		}
		else if ($elemConsult !== NULL)
		{
		   	$elem = new SElemOrg(1, 2, $this->prefixIdClass.LISTECLASS_ELEMENT, true, false, false);
		   	$elem->AjouterClasse(LISTECLASS_ELEMENT);
		   	$elem->AddClass(LISTE_JQ_ELEMENTMODELE);
		   	$elem->SetCelluleDominante(1, 1);
		   	$elem->AttacherCellule(1, 1, $divConsult);
		   	$elem->AttacherCellule(1, 2, $divMenu);
		}
		else if ($elemModif !== NULL)
		{
			$elem = new SElemOrg(1, 2, $this->prefixIdClass.LISTECLASS_ELEMENT, true, false, false);
		   	$elem->AjouterClasse(LISTECLASS_ELEMENT);
		   	$elem->AddClass(LISTE_JQ_ELEMENTMODELE);
		   	$elem->SetCelluleDominante(1, 1);
		   	$elem->AttacherCellule(1, 1, $divModif);
		   	$elem->AttacherCellule(1, 2, $divMenu);
		}
		else
		   	GLog::LeverException(EXS_0000, 'SListe::ConstruireElementModele, la liste de type ['.$this->TypeSynchro().'] n\'a pas d\'�l�ment mod�le pour le contexte ['.$this->contexte.'].');

		if ($elem !== NULL)
			$elem->AddProp(PROP_STYLE, 'visibility: hidden; height:0;');

		return $elem;
	}

	// Construction de la liste avec v�rification des droits.
	protected function ConstruireListe()
	{
	   	if ($this->rechargement === false)
		{
			// Construction de la partie triable de la liste si elle l'est.
			$this->ConstruireListeTriable();

			// Construction de la fonction appel�e en cas de changement de page.
		   	$divChangePageFonc = new SBalise(BAL_DIV);
		   	$divChangePageFonc->AddClass(LISTE_JQ_PAGE_CHANGEFONC);
		   	$divChangePageFonc->SetText($this->foncAjaxRechargement);
		   	$this->Attach($divChangePageFonc);

		   	// Construction des param�tres pour la fonction appel�e en cas de changement de page.
		   	$divChangePageParam = new SBalise(BAL_DIV);
		   	$divChangePageParam->AddClass(LISTE_JQ_PAGE_CHANGEPARAM);
		   	$param = 'contexte='.$this->contexte.'&'.$this->contexte.'[page]['.$this->TypeSynchro().']['.$this->Numero().']';
		   	$divChangePageParam->SetText(to_html($param));
		   	$this->Attach($divChangePageParam);

		   	// Construction du type de synchronisation de la liste (utilis� pour recharger une liste via ajax).
		   	$divTypeSynchro = new SBalise(BAL_DIV);
		   	$divTypeSynchro->AddClass(LISTE_JQ_TYPESYNCHRO);
		   	$divTypeSynchro->SetText($this->TypeSynchroPage());
		   	$this->Attach($divTypeSynchro);

		   	// Construction du num�ro de la liste (utilis� pour recharger une liste unique via ajax).
		   	$divNumero = new SBalise(BAL_DIV);
		   	$divNumero->AddClass(LISTE_JQ_NUMERO);
		   	$divNumero->SetText(strval($this->Numero()));
		   	$this->Attach($divNumero);

			// Construction de la ligne de titre.
			$ligneTitre = $this->ConstruireLigneTitre();
			if ($ligneTitre !== NULL)
			   	$this->Attach($ligneTitre);

			// Construction d'une ligne de changement de page.
			$changePage = $this->ConstruireChangementPage();
			if ($changePage !== NULL)
			   	$this->Attach($changePage);

			$elemModele = $this->ConstruireElementModele();
			if ($elemModele !== NULL)
			   	$this->Attach($elemModele);
		}

		// Construction des �l�ments de la liste.
		$ordre = 0;
		$poidsJavascriptMax = GSession::PoidsJavascriptMax();
		foreach ($this->elements as &$element)
		{
		   	if (GSession::PoidsJavascript() <= $poidsJavascriptMax)
			{
			   	$this->InitialiserReferentielsElement($element);
				$elem = $this->ConstruireElement($element, $ordre);
				if ($element[LISTE_ELEMENT_ACTION] == LISTE_ELEMACTION_CREAT)
				   	GSession::PoidsJavascript(8);
				else if ($element[LISTE_ELEMENT_ACTION] == LISTE_ELEMACTION_MODIF && array_key_exists(LISTE_ELEMENT_MODIFIE, $element) && $element[LISTE_ELEMENT_MODIFIE] === true)
				   	GSession::PoidsJavascript(2);

				if ($this->rechargement === false)
				   	$this->Attach($elem);
				else
				   	$element[LISTE_ELEMENT_CONTENU] = $elem;
				$ordre++;
			}
			else
			{
			   	GReponse::AjouterElementSuite();
			   	break;
			}
		}

		// Suppression des �l�ments qui ne font plus partie de la liste.
		if ($this->listeSuppressions !== NULL)
		{
			foreach ($this->listeSuppressions as $id => $elemSupp)
			{
			   	$elementSupp = array();
				$elementSupp[LISTE_ELEMENT_ID] = $id;
				$elementSupp[LISTE_ELEMENT_ACTION] = LISTE_ELEMACTION_SUPP;
				GSession::PoidsJavascript(1);
				$this->elements[] = $elementSupp;

				// Suppression du contexte.
				if (array_key_exists($id, $this->listeContexte))
				   	unset($this->listeContexte[$id]);
			}
		}

		if ($this->rechargement === false)
		{
		   	// Construction d'une ligne de changement de page.
			$changePage = $this->ConstruireChangementPage();
			if ($changePage !== NULL)
			   	$this->Attach($changePage);

			// Construction de l'�l�ment de cr�ation.
			if ($this->HasDroitCreation())
			{
				$elemCreat = $this->ConstruireElementCreation();
				if ($elemCreat)
				{
				   	GSession::PoidsJavascript(8);
					$this->Attach($elemCreat);
				}
			}
		}

		// Sauvegarde de la liste dans le contexte.
		// Si on a chang� de page, on supprime l'ancienne liste du contexte.
		GContexte::Liste($this->contexte, $this->TypeSynchroPage(), $this->listeContexte);
	}

	public function GetElementsPourRechargement()
	{
	   	if ($this->chargement === true)
	   	{
			$this->rechargement = true;
		   	$this->ConstruireListe();
		   	return $this->elements;
		}
		return array();
	}

	public function BuildHTML()
	{
	   	if ($this->chargement === true)
	   	{
		   	$this->listeContexte = array();
		   	$this->listeSuppressions = NULL;
			$this->ConstruireListe();
			GContexte::ListeActive($this->contexte, $this->TypeSynchroPage());
			return parent::BuildHTML();
		}
		return '';
	}
}

?>