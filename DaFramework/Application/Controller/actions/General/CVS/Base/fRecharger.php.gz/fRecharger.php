<?php

require_once 'cst.php';
require_once INC_GSESSION;
require_once INC_SLISTE;


GReponse::Debut();


$contexte = GSession::LirePost('contexte');
if ($contexte === NULL || $contexte === '')
   	GContexte::ChargerContextes();
else
{
   	$page = GContexte::LireVariablePost($contexte, 'page');
   	$etage = GContexte::LireVariablePost($contexte, 'etage');
   	if ($contexte !== NULL && $page !== NULL && $page !== '')
	   	SListe::SetChangementPage($page);
	else if ($contexte !== NULL && $etage !== NULL && $etage !== '')
	   	SListe::SetChargementEtage($etage);
   	GContexte::ChargerContexte($contexte);
}


GReponse::Fin();

?>