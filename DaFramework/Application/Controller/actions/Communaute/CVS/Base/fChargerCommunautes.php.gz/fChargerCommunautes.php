<?php

require_once 'cst.php';
require_once INC_GSESSION;
require_once INC_SFORM;
require_once PATH_METIER.'mListeCommunautes.php';


$mListeCommunautes = new MListeCommunautes(false);
$mListeCommunautes->AjouterToutesColSelection();
$mListeCommunautes->AjouterColOrdre(COL_LIBELLE);
$mListeCommunautes->Charger();

$selectCommunaute = new SForm('selcom', 1, 1);
$selectCommunaute->SetCadreInputs(1, 1, 1, 1);
$select = $selectCommunaute->AjouterInputSelect(1, 1, GSession::Libelle(LIB_CON_COMMUNAUTE), '', true, GContexte::FormaterVariable($nomContexte, 'communaute'));
foreach($mListeCommunautes->GetListe() as $communaute)
{
   	$select->AjouterElement($communaute->Id(), $communaute->Libelle());
}

GContexte::AjouterContenu(CADRE_INFO_COMMUNAUTE, $selectCommunaute);

?>
