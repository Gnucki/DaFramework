<?php

require_once 'cst.php';
require_once INC_SINPUTNEW;


// Input de type select avec un ou plusieurs formulaires popup.
class SInputNewSelect extends SInputNew
{
	public function __construct($prefixIdClass, $oblig = false, $retour = '', $info = '', $erreur = '', $type = '', $impact = '', $rechargeFonc = '')//, $cadre = true)
	{
	   	$this->select = new SInputSelect($prefixIdClass.INPUTNEW, INPUTSELECT_TYPE_NEW, $oblig, $retour, $info, $erreur, $type, $impact, $rechargeFonc);//, $cadre);

		parent::__construct($prefixIdClass, INPUTNEW_TYPE_SELECT, $oblig);
	}

	public function AjouterCategorie($id, $libelle)
	{
		if ($this->select != NULL)
			$this->select->AjouterCategorie($id, $libelle);
	}

	public function AjouterElement($id, $libelle, $description = '', $valParDefaut = false)
	{
		if ($this->select != NULL)
			$this->select->AjouterElement($id, $libelle, $description, $valParDefaut);
	}
}